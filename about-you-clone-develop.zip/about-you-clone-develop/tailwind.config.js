/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
    "./src/modules/**/*.{js,ts,jsx,tsx}",
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/design/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      height: {
        100: "100px",
      },
      width: {
        30: "30px",
      },
      animation: {
        "fade-in-right": "fadeInRight 1s ease-in-out",
        "fade-in": "fadeIn 1s ease-out",
      },
      fontFamily: {
        sans: ['"Open Sans Condensed"', "sans-serif"],
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic":
          "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
      },
      keyframes: {
        ripple: {
          "75%,100%": {
            transform: "scale(120)",
            opacity: "0",
          },
        },
        wiggle: {
          "50%": {
            transform: "translateX(1rem)",
          },
          "80%": {
            transform: "translateX(-1rem)",
          },
        },
        heart: {
          "50%": {
            transform: "scale(0.7)",
          },
        },
        loading: {
          "0%": {
            transform: "translateX(-100%)",
          },
          "80%": {
            transform: "translateX(100%)",
          },
        },
      },
      animation: {
        ripple: "ripple 30s cubic-bezier(0, 0, 0.2, 1)",
        wiggle: "wiggle 0.4s ease-in-out",
        heart: "heart 1.5s cubic-bezier(0, 0, 0.2, 1) infinite",
        loading: "loading 2s ",
      },
      spacing: {
        xxs: "5px",
        xs: "10px",
        sm: "16px",
        md: "20px",
        lg: "24px",
        xl: "30px",
        "2xl": "40px",
        "3xl": "60px",
        "4xl": "80px",
      },

      colors: {
        black: {
          DEFAULT: "#000000",
          dark: "#181818",
          darker: "#000000",
        },
        white: "#FFFFFF",
        red: {
          DEFAULT: "#E72D34",
          dark: "#C3262C",
        },
        blue: "#1878F2",
        green: "#70EAB4",
        grey: {
          lighter: "#CCCCCC",
          lightLight: "#F2F2F2",
          light: "#F4F4F5",
          DEFAULT: "#B7B7B7",
          lightDark: "#DBDBDC",
          dark: "#9B9B9B",
        },
        yellow: "#FFE899",
      },
      fontFamily: {
        "sans-serif": ["Mark Pro, Mark Pro Fallback, sans-serif"],
      },

      fontSize: {
        xxs: "0.625rem",
        xs: "0.75rem",
        sm: "0.875rem",
        xls: "1.375rem",
        xxl: "2rem",
      },
      fontWeight: {
        medium: "500",
        semibold: "600",
        bold: "700",
        black: "900",
      },
    },
    screens: {
      sm: "480px",
      md: "768px",
      lg: "1024px",
      xl: "1280px",
      "2xl": "1440px",
    },
  },
  plugins: [
    require("tailwindcss-animations"),
    require("@tailwindcss/typography"),
  ],
  variants: {
    display: ["responsive", "group-hover", "group-focus"],
  },
};
