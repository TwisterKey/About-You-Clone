import { CartItem } from "./context";
export interface CartStrategy {
  getCartItems: () => Promise<CartItem[]>;
  addItem: (item: CartItem) => any;
  removeItem: (itemId: number) => Promise<void>;
  updateItemQuantity: (itemId: number, newQuantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
}
