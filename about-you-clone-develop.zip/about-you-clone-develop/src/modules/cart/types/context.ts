export type CartItem = {
    id: number;
    image: any;
    title: string;
    size: string;
    color: string;
    quantity: number;
    price: number;
  };