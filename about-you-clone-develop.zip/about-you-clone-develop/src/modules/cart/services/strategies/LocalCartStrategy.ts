import { CartItem } from "../../types/context";
import { CartStrategy } from "../../types/strategy";

export class LocalCartStrategy implements CartStrategy {
  private localStorageKey = "cartItems";
  async getCartItems(): Promise<CartItem[]> {
    const storedItems = localStorage.getItem("cartItems");
    return storedItems ? JSON.parse(storedItems) : [];
  }

  async addItem(item: CartItem): Promise<void> {
    const currentItems = await this.getCartItems();
    const updatedItems = [...currentItems, { ...item }];
    localStorage.setItem(this.localStorageKey, JSON.stringify(updatedItems));
  }

  async removeItem(itemId: number): Promise<void> {
    const currentItems = await this.getCartItems();
    const updatedItems = currentItems.filter((item) => item.id !== itemId);
    localStorage.setItem(this.localStorageKey, JSON.stringify(updatedItems));
  }

  async updateItemQuantity(itemId: number, newQuantity: number): Promise<void> {
    const currentItems = await this.getCartItems();
    const updatedItems = currentItems.map((item) =>
      item.id === itemId ? { ...item, quantity: newQuantity } : item
    );
    localStorage.setItem(this.localStorageKey, JSON.stringify(updatedItems));
  }

  async clearCart(): Promise<void> {
    localStorage.removeItem(this.localStorageKey);
  }
}
