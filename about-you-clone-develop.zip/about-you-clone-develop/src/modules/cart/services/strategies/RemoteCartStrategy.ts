import { apiClient } from "@/lib/axios";
import { CartStrategy } from "../../types/strategy";
import { CartItem } from "@/modules/cart/types/context";

export class RemoteCartStrategy implements CartStrategy {
  async getCartItems() {
    const { data } = await apiClient.get("/cart");
    return data;
  }

  async addItem(item: CartItem) {
    await apiClient.post("/cart", item);
  }

  async removeItem(itemId: number) {
    await apiClient.delete(`/cart/${itemId}`);
  }

  async updateItemQuantity(itemId: number, newQuantity: number) {
    await apiClient.patch(`/cart/${itemId}`, { quantity: newQuantity });
  }

  async clearCart() {
    await apiClient.delete("/cart/clear");
  }
}
