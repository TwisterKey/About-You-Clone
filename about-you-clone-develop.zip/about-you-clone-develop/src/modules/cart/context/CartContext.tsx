import React, { createContext, use, useContext, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CartItem } from "../types/context";
import { LocalCartStrategy } from "../services/strategies/LocalCartStrategy";
import { RemoteCartStrategy } from "./../services/strategies/RemoteCartStrategy";
import { CartStrategy } from "../types/strategy";

interface CartContextData {
  items: CartItem[];
  addItem: (item: CartItem) => Promise<void>;
  removeItem: (itemId: number) => Promise<void>;
  updateItemQuantity: ({
    itemId,
    newQuantity,
  }: {
    itemId: number;
    newQuantity: number;
  }) => Promise<void>;
  clearCart: () => Promise<void>;
}

type CartProviderProps = {
  children: React.ReactNode;
};

const CartContext = createContext<CartContextData | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};

export const CartProvider = ({ children }: CartProviderProps) => {
  const queryClient = useQueryClient();
  const [strategy, setStrategy] = React.useState<CartStrategy>(
    new LocalCartStrategy()
  );

  const { data: items } = useQuery({
    queryKey: ["cart"],
    queryFn: strategy.getCartItems,
    enabled: !!strategy,
  });

  const addItem = useMutation({
    mutationFn: async (newItem: CartItem) => {
      const existingItem = items?.find((i) => i.id === newItem.id);
      if (existingItem) {
        let itemId = newItem.id;
        let newQuantity = existingItem.quantity + 1;
        updateItemQuantity.mutate({ itemId, newQuantity });
      } else {
        await strategy?.addItem(newItem);
      }
    },
    onMutate: async (newItem: CartItem) => {
      await queryClient.cancelQueries({ queryKey: ["cart"] });
      const previousItems: CartItem[] =
        queryClient.getQueryData(["cart"]) || [];
      queryClient.setQueryData(["cart"], [...previousItems, newItem]);
      return { previousItems };
    },
    onError: ({ context }) => {
      queryClient.setQueryData(["cart"], context ? context.previousItems : []);
    },
    onSettled: () => {
      queryClient.invalidateQueries(["cart"]);
    },
  });

  const removeItem = useMutation({
    mutationFn: async (itemId: number) => {
      await strategy?.removeItem(itemId);
    },
    onMutate: async (itemId: number) => {
      await queryClient.cancelQueries({ queryKey: ["cart"] });
      const previousItems: CartItem[] =
        queryClient.getQueryData(["cart"]) || [];
      queryClient.setQueryData(
        ["cart"],
        previousItems.filter((item) => item.id !== itemId)
      );
      return { previousItems };
    },
    onError: ({ context }) => {
      queryClient.setQueryData(["cart"], context ? context.previousItems : []);
    },
    onSettled: () => {
      queryClient.invalidateQueries(["cart"]);
    },
  });

  const updateItemQuantity = useMutation({
    mutationFn: async ({
      itemId,
      newQuantity,
    }: {
      itemId: number;
      newQuantity: number;
    }) => {
      await strategy?.updateItemQuantity(itemId, newQuantity);
    },
    onMutate: async ({
      itemId,
      newQuantity,
    }: {
      itemId: number;
      newQuantity: number;
    }) => {
      await queryClient.cancelQueries({ queryKey: ["cart"] });
      const previousItems: CartItem[] =
        queryClient.getQueryData(["cart"]) || [];
      queryClient.setQueryData(
        ["cart"],
        previousItems.map((item) =>
          item.id === itemId ? { ...item, quantity: newQuantity } : item
        )
      );
      return { previousItems };
    },
    onError: ({ context }) => {
      queryClient.setQueryData(["cart"], context ? context.previousItems : []);
    },
    onSettled: () => {
      queryClient.invalidateQueries(["cart"]);
    },
  });

  const clearCart = useMutation({
    mutationFn: async () => {
      await strategy?.clearCart();
    },
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ["cart"] });
      const previousItems: CartItem[] =
        queryClient.getQueryData(["cart"]) || [];
      queryClient.setQueryData(["cart"], []);
      return { previousItems };
    },
    onError: ({ context }) => {
      queryClient.setQueryData(["cart"], context ? context.previousItems : []);
    },
    onSettled: () => {
      queryClient.invalidateQueries(["cart"]);
    },
  });

  return (
    <CartContext.Provider
      value={{
        items: items || [],
        addItem: addItem.mutateAsync,
        removeItem: removeItem.mutateAsync,
        updateItemQuantity: updateItemQuantity.mutateAsync,
        clearCart: clearCart.mutateAsync,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
