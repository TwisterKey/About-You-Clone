import { useCart } from "../context/CartContext";

export const CartItemsProductQuantitySelect = ({
  id,
  quantity,
}: {
  id: number;
  quantity: number;
}) => {
  const { updateItemQuantity } = useCart();

  const handleQuantityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newQuantity = parseInt(e.target.value);
    updateItemQuantity({ itemId: id, newQuantity });
  };

  const quantityOptions = () => {
    const options = [];
    for (let i = 1; i <= 9; i++) {
      options.push(
        <option key={`option-${id}-${i}`} value={i}>
          {i}
        </option>
      );
    }

    return options;
  };

  return (
    <select
      id="itemsQuantity"
      value={quantity}
      onChange={handleQuantityChange}
      className="border rounded-sm px-xs py-xxs"
    >
      {quantityOptions()}
    </select>
  );
};
