import { useTranslation } from "next-i18next";

export const CartItemsHeader = () => {
  const { t } = useTranslation("common");
  return (
    <section className="flex justify-between content-top">
      <h2 className="font-semibold text-md">{t("delivery")}</h2>
      <div className="px-xs py-xxs bg-grey-lightLight rounded-full text-sm font-medium ">
        mie., 10.05 - vin., 12.05
      </div>
    </section>
  );
};
