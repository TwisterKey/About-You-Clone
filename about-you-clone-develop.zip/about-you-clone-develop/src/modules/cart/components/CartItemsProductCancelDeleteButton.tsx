import { useTranslation } from "next-i18next";
import { ArrowPathIcon } from "@heroicons/react/24/outline";
import { Button } from "@/components/Elements/Button";

export const CartItemsProductCancelDeleteButton = ({
  handleCancelDelete,
}: {
  handleCancelDelete: () => void;
}) => {
  const { t } = useTranslation("common");

  return (
    <section className="flex items-center">
      <div>
        <p className="text-sm text-center font-semibold mb-sm">
          {t("deleteItem")}
        </p>
        <Button
          onClick={handleCancelDelete}
          size="large"
          color="black"
          startIcon
          variant="outline"
          className="mx-md py-xs border-[1px]"
        >
          <ArrowPathIcon className="h-md w-md mr-2 self-center font-bold" />
          {t("cancel")}
          <div className="absolute bg-black-dark inset-x-0 bottom-0 p-[2px]  animate-loading"></div>
        </Button>
      </div>
    </section>
  );
};
