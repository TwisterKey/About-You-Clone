import { useCart } from "../context/CartContext";
import { Tile } from "@/components/Elements/Tile/Tile";
import { CartItemsHeader } from "./CartItemsHeader";
import { CartItemsProduct } from "./CartItemsProduct";
import { CartItemsFooter } from "./CartItemsFooter";
import { CartItem } from "../types/context";

export const CartItemsTile = () => {
  const { items } = useCart();
  return (
    <Tile className="w-[63%] relative pb-2xl">
      <CartItemsHeader />
      <section className="flex flex-col">
        {items.map((item: CartItem) => (
          <CartItemsProduct key={item.id} item={item} />
        ))}
      </section>
      <CartItemsFooter />
    </Tile>
  );
};
