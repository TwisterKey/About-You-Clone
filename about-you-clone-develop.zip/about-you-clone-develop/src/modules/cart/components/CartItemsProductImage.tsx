import clsx from "clsx";
import Image from "next/image";
import { twMerge } from "tailwind-merge";
import { useState } from "react";
import { HeartIcon } from "@heroicons/react/24/outline";
import { Button } from "@/components/Elements/Button";

export const CartItemsProductImage = ({ image }: { image: string }) => {
  const [inWishlist, setInWishlist] = useState(false);

  function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    event.preventDefault();
    setInWishlist(!inWishlist);
  }

  return (
    <div className="relative h-[160px] w-[130px] bg-grey-light p-xs flex rounded-sm">
      <Image
        src={image}
        alt="Primary Image"
        className="w-full rounded-lg object-contain "
        width={140}
        height={160}
      />

      <Button
        size="small"
        color="black"
        variant="text"
        onClick={handleClick}
        className="absolute right-0 top-0 flex items-center justify-center overflow-visible"
      >
        <HeartIcon
          className={twMerge(
            clsx(
              "z-10 h-lg w-lg text-black hover:animate-heart",
              inWishlist && "fill-black"
            )
          )}
        />
      </Button>
    </div>
  );
};
