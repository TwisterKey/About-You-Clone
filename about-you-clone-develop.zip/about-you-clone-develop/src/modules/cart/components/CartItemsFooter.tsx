import { useTranslation } from "next-i18next";
import { ExclamationCircleIcon } from "@heroicons/react/24/outline";

export const CartItemsFooter = () => {
  const { t } = useTranslation("common");
  return (
    <div className="py-xs px-lg text-grey border-t inset-x-0 absolute text-xxs flex items-center h-min">
      <ExclamationCircleIcon className="h-md w-md mr-2 ml- self-center font-bold" />
      <p className="h-min">{t("notRezerved")}</p>
    </div>
  );
};
