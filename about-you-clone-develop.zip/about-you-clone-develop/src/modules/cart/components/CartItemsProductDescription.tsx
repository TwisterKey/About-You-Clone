import { useTranslation } from "next-i18next";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { Button } from "@/components/Elements/Button";
import { CartItemsProductQuantitySelect } from "./CartItemsProductQuantitySelect";

export const CartItemsProductDescription = ({
  id,
  title,
  size,
  color,
  price,
  quantity,
  handleDelete,
}: {
  id: number;
  title: string;
  size: string;
  color: string;
  price: number;
  quantity: number;
  handleDelete: (id: number) => void;
}) => {
  const { t } = useTranslation("common");

  return (
    <section className="flex w-full justify-between">
      <div className="ml-lg py-xs flex flex-col justify-between">
        <section className=" text-xs">
          <h4 className="mb-xxs font-bold ">{title}</h4>
          <div>Type of item</div>
          <div>{size}</div>
          <div>{color}</div>
        </section>
        <Button
          onClick={() => handleDelete(id)}
          size="small"
          variant="text"
          color="black"
          startIcon
          className="pl-0 justify-start align-center"
        >
          <XMarkIcon className="h-sm w-sm mr-2" />
          {t("delete")}
        </Button>
      </div>
      <div className="flex flex-col justify-between">
        <CartItemsProductQuantitySelect
          key={`selectQuantity-${id}`}
          id={id}
          quantity={quantity}
        />
        <div className="font-medium text-md">{price} lei</div>
      </div>
    </section>
  );
};
