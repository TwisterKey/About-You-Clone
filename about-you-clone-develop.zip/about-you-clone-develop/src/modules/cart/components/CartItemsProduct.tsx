import { useState } from "react";
import { useCart } from "../context/CartContext";
import { CartItem } from "../types/context";
import { CartItemsProductImage } from "./CartItemsProductImage";
import { CartItemsProductDescription } from "./CartItemsProductDescription";
import { CartItemsProductCancelDeleteButton } from "./CartItemsProductCancelDeleteButton";

export const CartItemsProduct = ({ item }: { item: CartItem }) => {
  const { id, image, title, size, color, quantity, price } = item;
  const [cancelDelete, setCancelDelete] = useState(false);
  const { removeItem } = useCart();

  const handleDelete = (id: number) => {
    setCancelDelete(true);
    setTimeout(() => {
      setCancelDelete((cancelDelete) => {
        if (cancelDelete) {
          removeItem(id);
          return false;
        }
        return false;
      });
    }, 2300);
  };

  const handleCancelDelete = () => {
    setCancelDelete(false);
  };

  return (
    <div className="w-full flex py-lg">
      <CartItemsProductImage key={`productImage-${id}`} image={image} />
      <section className="flex w-full justify-between">
        {cancelDelete && (
          <CartItemsProductCancelDeleteButton
            handleCancelDelete={handleCancelDelete}
          />
        )}
        {!cancelDelete && (
          <CartItemsProductDescription
          key={`productDescription-${id}`}
            id={id}
            title={title}
            size={size}
            color={color}
            price={price}
            quantity={quantity}
            handleDelete={handleDelete}
          />
        )}
      </section>
    </div>
  );
};
