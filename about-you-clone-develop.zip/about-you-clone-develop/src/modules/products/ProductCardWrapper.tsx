import { ReactNode } from "react";
import { createContext } from "react";
import Link from "next/link";
import { PrimaryImage } from "./ProductCardPrimaryImage";
import { SecondaryImage } from "./ProductCardSecondaryImage";
import { Body } from "./ProductCardBody";
import { Title } from "./ProductCardTitle";
import { Price } from "./ProductCardPrice";
import { Colors } from "./ProductCardColors";
import { FullWidthButton } from "./ProductCardButton";
import { Header } from "./ProductCardHeader";
import { Badges } from "./ProductCardBadges";
import { WishlistIconButton } from "./ProductCardWishlistIconButton";
import { SustainabilityIconButton } from "./ProductCardSustainabilityIconButton";
import { OtherText } from "./ProductCardOtherText";
import { Sizes } from "./ProductCardSizes";
import { BodyFrontPage } from "./ProductsCardBody";

type CurentProductCardContextType = {
  id: number;
  title: string;
  price: number;
  discount?: number;
  currency: string;
  colors: Array<string>;
  badges?: Array<string>;
  icons?: string;
  wishlist?: boolean;
  sizes: Array<string>;
  text?: string;
  primaryImage: any;
  secondaryImage: any;
};

export const CurentProductCardContext =
  createContext<CurentProductCardContextType>({
    id: 0,
    title: '',
    price: 0,
    currency: '',
    colors: [],
    sizes: [],
    primaryImage: null,
    secondaryImage: null,
  });

type CardProps = {
  children: ReactNode;
};

type Props = CurentProductCardContextType & CardProps;

export const Card = ({
  children,
  id,
  title,
  price,
  discount,
  currency,
  colors,
  badges,
  icons,
  wishlist,
  sizes,
  text,
  primaryImage,
  secondaryImage,
}: Props) => {
  return (
    <CurentProductCardContext.Provider
      value={{
        id,
        title,
        price,
        discount,
        currency,
        colors,
        badges,
        icons,
        wishlist,
        sizes,
        text,
        primaryImage,
        secondaryImage,
      }}
    >
      <div className="relative w-full text-black group overflow-hidden">
        <Link href="/" className="flex flex-col">
          {children}
        </Link>
      </div>
    </CurentProductCardContext.Provider>
  );
};

Card.PrimaryImage = PrimaryImage;
Card.SecondaryImage = SecondaryImage;
Card.Body = Body;
Card.BodyFrontPage = BodyFrontPage;
Card.Header = Header;
Card.Title = Title;
Card.Price = Price;
Card.Colors = Colors;
Card.Sizes = Sizes;
Card.FullWidthButton = FullWidthButton;
Card.Badges = Badges;
Card.WishlistIconButton = WishlistIconButton;
Card.SustainabilityIconButton = SustainabilityIconButton;
Card.OtherText = OtherText;
