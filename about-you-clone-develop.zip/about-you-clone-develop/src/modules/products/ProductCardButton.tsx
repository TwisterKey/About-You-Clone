import { Button } from "../../components/Elements/Button/Button";
import { useTranslation } from "next-i18next";
import { useCart } from "../cart/context/CartContext";
import { useContext } from "react";
import { CurentProductCardContext } from "./ProductCardWrapper";

export function FullWidthButton() {
  const { t } = useTranslation("common");
  const { addItem } = useCart();
  const currentCard = useContext(CurentProductCardContext);

  const item = {
    id: currentCard.id,
    image: currentCard.primaryImage,
    title: currentCard.title,
    price: currentCard.price,
    size: "XL",
    color: "black",
    quantity: 1,
  };

  return (
    <div className="absolute p-sm inset-x-0 opacity-0 ease-in duration-500 group-hover:opacity-100 bg-white">
      <Button
        onClick={(event) => {
          event.preventDefault();
          addItem(item);
        }}
        size="veryLarge"
        enableFullWidth={true}
        enableHoverEffect="translateEffectUp"
        color="black"
        variant="contained"
      >
        {t("addToBasket")}
      </Button>
    </div>
  );
}
