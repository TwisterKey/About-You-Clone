import Image from "next/image";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext, ReactNode } from "react";

type PrimaryImageProps = {
  children: ReactNode;
};

export function PrimaryImage({ children }: PrimaryImageProps) {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="relative w-full h-fit z-10 bg-grey-light p-lg  rounded-lg transition-opacity ease-in-out duration-300 group-hover:opacity-0">
      <Image
        src={currentCard?.primaryImage}
        alt="Primary Image"
        className="w-full rounded-lg"
        width={500}
        height={500}
      />
      {children}
    </div>
  );
}
