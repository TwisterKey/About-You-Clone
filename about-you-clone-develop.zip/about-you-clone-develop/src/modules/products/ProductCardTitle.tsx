import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";

export function Title() {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <h4 className="uppercase font-semibold text-sm tracking-wider">
      {currentCard?.title}
    </h4>
  );
}
