import { useTranslation } from "next-i18next";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";

export function OtherText() {
  const { t } = useTranslation("common");
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="text-grey-dark text-xxs mt-xs bg-white">
      {currentCard?.text && t(currentCard?.text as any)}
    </div>
  );
}
