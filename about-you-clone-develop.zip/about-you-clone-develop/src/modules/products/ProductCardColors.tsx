import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";

export function Colors() {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="h-2xl flex items-end group-hover:hidden">
      <ul className="flex gap-1 bottom-0 ">
        {currentCard?.colors &&
          currentCard?.colors.map((color: String, index: number) => {
            return (
              <li
                key={index}
                className={`rounded-full w-[18px] h-[18px] border`}
                style={{ backgroundColor: `${color}` }}
              />
            );
          })}
      </ul>
    </div>
  );
}
