import { Card } from "./ProductCardWrapper";

export { Card };

export type Product = {
    id: number,
    name: string,
    description: string,
    variants: [
        {
            id: number,
            price: number,
            discount: number,
            stock: number,
            images: [
                {
                    id: number,
                    url: string
                }
            ],
            filter: [
                {
                    id: number,
                    name: string
                }
            ]
        }

    ]
};
