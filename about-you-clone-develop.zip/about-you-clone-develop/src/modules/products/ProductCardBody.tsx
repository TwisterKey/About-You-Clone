import { ReactNode } from "react";

type BodyProps = {
  children: ReactNode;
};

export function Body({ children }: BodyProps) {
  return (
    <div className="relative p-sm pb-lg z-10 bg-white ease-in-out duration-500 group-hover:-translate-y-2/4 ">
      {children}
    </div>
  );
}
