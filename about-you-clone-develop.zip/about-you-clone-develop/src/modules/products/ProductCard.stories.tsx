import type { Meta, StoryObj } from "@storybook/react";
import ProductCard from "./ProductCard";
import { primaryImage, secondaryImage } from "./data";

const meta: Meta<typeof ProductCard> = {
  title: "Products/ProductCard",
  component: ProductCard,
  parameters: {
    backgrounds: { default: "light" },
  },
  decorators: [
    (Story) => (
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-3 2xl:grid-cols-4 justify-items-center">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ProductCard>;

export const SimpleProductCard: Story = {
  args: {
    currency: "lei",
    price: 50,
    title: "Brand Name",
    colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
    sizes: ["XL", "XS", "L"],
    primaryImage: primaryImage,
    secondaryImage: secondaryImage,
  },
};

export const BadgesProductCard: Story = {
  args: {
    currency: "lei",
    price: 50,
    title: "Brand Name",
    colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
    badges: ["Pont", "Premium"],
    sizes: ["XL", "XS", "L"],
    primaryImage: primaryImage,
    secondaryImage: secondaryImage,
  },
};

export const DiscountProductCard: Story = {
  args: {
    currency: "lei",
    price: 50,
    discount: 15,
    title: "Brand Name",
    colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
    sizes: ["XL", "XS", "L"],
    primaryImage: primaryImage,
    secondaryImage: secondaryImage,
  },
};

export const SustainabilityProductCard: Story = {
  args: {
    currency: "lei",
    price: 50,
    title: "Brand Name",
    colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
    sizes: ["XL", "XS", "L"],
    icons: "arrows",
    primaryImage: primaryImage,
    secondaryImage: secondaryImage,
  },
};

export const OtherTextProductCard: Story = {
  args: {
    currency: "lei",
    price: 50,
    title: "Brand Name",
    colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
    sizes: ["XL", "XS", "L"],
    icons: "arrows",
    text: "Cel mai bun pret din ultimele 30 de zile",
    primaryImage: primaryImage,
    secondaryImage: secondaryImage,
  },
};
