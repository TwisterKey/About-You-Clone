import clsx from "clsx";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";
import { twMerge } from "tailwind-merge";
import { useTranslation } from "next-i18next";

export function Badges() {
  const { t } = useTranslation("common");
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="absolute opacity-100 bottom-lg left-0 flex flex-col gap-1  ">
      {currentCard?.badges &&
        currentCard?.badges.map((badge: string, index: number) => {
          return (
            <span
              key={index}
              className="pl-sm pr-xs py-[3px] bg-white rounded-r-sm w-max text-sm FONT"
            >
              {t(badge as any)}
            </span>
          );
        })}
      <span
        className={twMerge(
          clsx(
            "hidden pl-sm pr-xs py-[2px] bg-red-dark text-white rounded-r-sm ",
            currentCard?.discount && "block"
          )
        )}
      >
        -{currentCard?.discount?.toString()}%
      </span>
    </div>
  );
}
