import clsx from "clsx";
import { Button } from "../../components/Elements/Button/Button";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { HeartIcon } from "@heroicons/react/24/outline";
import { useState, useContext } from "react";
import { twMerge } from "tailwind-merge";

export function WishlistIconButton() {
  const currentCard = useContext(CurentProductCardContext);
  const [inWishlist, setInWishlist] = useState(currentCard?.wishlist);

  function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    event.preventDefault();
    setInWishlist(!inWishlist);
  }

  return (
    <Button
      size="small"
      color="black"
      variant="text"
      enableClickEfect
      onClick={handleClick}
      className="flex items-center justify-center overflow-visible"
    >
      <HeartIcon className="relative h-xl w-xl text-white fill-white" />
      <HeartIcon
        className={twMerge(
          clsx(
            "absolute h-lg w-lg text-grey hover:animate-heart",
            inWishlist && "fill-black text-black"
          )
        )}
      />
    </Button>
  );
}
