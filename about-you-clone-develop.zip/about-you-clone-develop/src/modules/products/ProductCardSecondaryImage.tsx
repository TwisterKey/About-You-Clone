import Image from "next/image";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";

export function SecondaryImage() {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="absolute inset-x-0 top-5 w-full opacity-0 transition duration-300 group-hover:opacity-100 group-hover:-translate-y-5">
      <Image
        src={currentCard?.secondaryImage}
        alt="tricou"
        className="w-full rounded-lg"
        width={500}
        height={500}
      />
    </div>
  );
}
