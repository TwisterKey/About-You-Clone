import { ReactNode } from "react";

type HeaderProps = {
  children: ReactNode;
};

export function Header({ children }: HeaderProps) {
  return (
    <div className="absolute p-sm inset-x-0 top-0 z-10 flex flex-row-reverse justify-between items-center">
      {children}
    </div>
  );
}
