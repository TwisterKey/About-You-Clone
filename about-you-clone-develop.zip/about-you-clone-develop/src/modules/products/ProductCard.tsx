import { Card } from "./index";

type ProductCardProps = {
  id:number;
  title: string;
  price: number;
  discount?: number;
  currency: string;
  colors: Array<string>;
  badges?: Array<string>;
  icons?: string;
  wishlist?: boolean;
  sizes: Array<string>;
  text?: string;
  primaryImage: any;
  secondaryImage: any;
};

const ProductCard = (props: ProductCardProps) => {
  return (
    <Card {...props}>
      <Card.PrimaryImage>
        <Card.Badges />
      </Card.PrimaryImage>
      <Card.SecondaryImage />
      <Card.Header>
        <Card.WishlistIconButton />
        <Card.SustainabilityIconButton />
      </Card.Header>
      <Card.Body>
        <Card.Title />
        <Card.Price />
        <Card.Colors />
        <Card.Sizes />
        <Card.OtherText />
        <Card.FullWidthButton />
      </Card.Body>
    </Card>
  );
};

export default ProductCard;
