import clsx from "clsx";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";
import { ArrowPathIcon, ShieldCheckIcon } from "@heroicons/react/24/outline";
import { Button } from "../../components/Elements/Button/Button";

const iconPicker = (icon: String) => {
  switch (icon) {
    case "arrows":
      return <ArrowPathIcon className="w-sm h-sm" />;
    case "shield":
      return <ShieldCheckIcon className="w-sm h-sm" />;
    default:
      return;
  }
};

export function SustainabilityIconButton() {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div>
      <Button
        size="small"
        color="grey"
        variant="contained"
        enableClickEfect
        className={clsx(
          "flex items-center justify-center overflow-visible rounded-full h-xl w-xl bg-transparent",
          currentCard?.icons && "bg-grey-lightDark"
        )}
      >
        {currentCard?.icons && iconPicker(currentCard?.icons)}
      </Button>
    </div>
  );
}
