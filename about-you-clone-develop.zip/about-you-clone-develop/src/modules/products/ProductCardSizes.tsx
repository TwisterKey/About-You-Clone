import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";
import { useTranslation } from "next-i18next";

export function Sizes() {
  const { t } = useTranslation("common");
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="relative hidden h-2xl group-hover:block">
      <span className="text-grey-dark bottom-0 absolute text-sm">
        {t("size")}:&nbsp;{currentCard?.sizes?.toString()}
      </span>
    </div>
  );
}
