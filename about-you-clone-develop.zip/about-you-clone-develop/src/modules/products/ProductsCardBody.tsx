import { ReactNode } from "react";

type BodyProps = {
  children: ReactNode;
};

export function BodyFrontPage({ children }: BodyProps) {
  return (
    <div className="relative p-sm pb-lg z-10 bg-white ease-in-out duration-500 ">
      {children}
    </div>
  );
}
