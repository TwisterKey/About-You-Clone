import clsx from "clsx";
import { CurentProductCardContext } from "./ProductCardWrapper";
import { useContext } from "react";
import { twMerge } from "tailwind-merge";

export function Price() {
  const currentCard = useContext(CurentProductCardContext);
  return (
    <div className="font-medium text-sm">
      <p
        className={twMerge(
          clsx(`hidden pr-2 text-red-dark `, currentCard?.discount && `block`)
        )}
      >
        {(Number(currentCard?.discount?.toString()) * 100) /
          Number(currentCard?.price.toString())}
        &nbsp;{currentCard?.currency}
      </p>
      <p
        className={clsx(
          `pr-2`,
          currentCard?.discount && "text-grey-dark line-through"
        )}
      >
        {currentCard?.price.toString()} &nbsp;{currentCard?.currency}
      </p>
    </div>
  );
}
