export const Filter = () => {
  return (
    <div className="flex justify-center items-center bg-slate-300 text-black hover:bg-slate-400 px-4 py-8 mx-2 hover:cursor-pointer">
      <p>Whatever this is a single filter</p>
    </div>
  );
};

export default Filter;
