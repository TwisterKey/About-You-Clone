import Filter from "./Filter";

export const FilterBar = () => {
  return (
    <div className="flex justify-start items-center">
      <Filter />
      <Filter />
    </div>
  );
};

export default FilterBar;
