import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { appWithTranslation } from "next-i18next";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { CartProvider } from "@/modules/cart/context/CartContext";
import Layout from "@/components/Layout/Layout";
import "next-i18next.config";
import { GenderProvider } from "@/context/GenderContext";

const queryClient = new QueryClient();

function App({ Component, pageProps }: AppProps) {
  return (
    <QueryClientProvider client={queryClient}>
      <GenderProvider>
        <CartProvider>
          <Layout>
            <Component {...pageProps} />
          </Layout>
          <ReactQueryDevtools />
        </CartProvider>
      </GenderProvider>
    </QueryClientProvider>
  );
}

export default appWithTranslation(App);
