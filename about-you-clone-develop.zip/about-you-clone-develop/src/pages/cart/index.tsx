import { CartItemsTile } from "@/modules/cart/components/CartItemsTile";
import { GetServerSideProps } from "next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import { useTranslation } from "next-i18next";
import Link from "next/link";
import Head from "next/head";
import FilterBar from "@/modules/filters/FilterBar";
export default function Home() {
  const router = useRouter();
  const { t } = useTranslation("common");
  return (
    <>
      <Head>
        <title>{t("basket")}</title>
        <meta name="description" content="Check out the items from cart." />
      </Head>
      <div className="min-h-screen px-3xl">
        <h1 className="flex items-center w-full my-sm text-xxl  font-bold">
          {t("basket")}
        </h1>
        <div className="flex">
          <CartItemsTile />
        </div>
      </div>
    </>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ locale }) => {
  return {
    props: {
      ...(await serverSideTranslations(locale as string, [
        "common",
        "footer",
        "header",
      ])),
    },
  };
};
