import { Product } from "@/modules/products";
import ProductCard from "@/modules/products/ProductCard";
import { primaryImage, secondaryImage } from "@/modules/products/data";
import { GetServerSideProps } from "next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";

type MappedProductProps = {
  currency: string;
  price: number;
  title: string;
  colors: string[];
  sizes: string[];
  primaryImage: string;
  secondaryImage: string;
};

type ProductsProps = {
  products: MappedProductProps[];
};

export default function Page({ products }: ProductsProps) {
  return (
    <>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 justify-items-center mx-12">
        {products.map((product: MappedProductProps, productIndex: number) => {
          return (
            <ProductCard
              key={productIndex}
              currency="lei"
              price={50}
              title={product.title!}
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["pont", "premium"]}
              icons={"shield"}
              sizes={["XL", "XS"]}
              wishlist={true}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
              id={0}
            />
          );
        })}
      </div>
    </>
  );
}

function convertData(data: Product[]): MappedProductProps[] {
  return data.map((dataItem) => {
    return {
      currency: "lei",
      price: 0,
      title: dataItem.name,
      colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
      sizes: ["XL", "XS", "L"],
      primaryImage: "",
      secondaryImage: "",
    };
  });
}

export const getServerSideProps: GetServerSideProps = async ({ locale }) => {
  const res = await fetch(`https://lsp2023.web-staging.eu/api/products`);
  const data = await res.json();
  const convertedData = convertData(data);

  return {
    props: {
      ...(await serverSideTranslations(locale as string, [
        "common",
        "footer",
        "header",
      ])),
      products: convertedData.slice(0, 5),
    },
  };
};
