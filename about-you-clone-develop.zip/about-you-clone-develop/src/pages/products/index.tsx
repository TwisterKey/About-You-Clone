import { GetServerSideProps } from "next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import Link from "next/link";
import Head from "next/head";
import FilterBar from "@/modules/filters/FilterBar";
import ProductCard from "@/modules/products/ProductCard";
import { primaryImage, secondaryImage } from "@/modules/products/data";

export default function Home() {
  const router = useRouter();

  return (
    <>
      <Head>
        <title>Products</title>
        <meta
          name="description"
          content="Check out the brand new collection of Calvin Klein."
        />
      </Head>
      <div className="min-h-screen">
        <FilterBar />
        <div className="flex justify-between items-center w-full p-10">
          {/* <Link
            className="bg-slate-900 text-white p-4 border-1 border-solid border-gray-600 cursor-pointer"
            href={router.pathname}
            locale={"ro"}
          >
            Change locale to ro
          </Link>

          <Link
            className="bg-slate-900 text-white p-4 border-1 border-solid border-gray-600 cursor-pointer"
            href={router.pathname}
            locale={"en"}
          >
            Change locale to en
          </Link> */}
        </div>
        <div className="flex p-24">
          <div className="grid grid-cols-2 gap-4 xl:grid-cols-3 2xl:grid-cols-4 justify-items-center">
            <ProductCard
              id={1}
              currency="lei"
              price={130}
              title="BOSS"
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["pont", "premium"]}
              icons={"shield"}
              sizes={["XL", "XS"]}
              wishlist={true}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
            />
            <ProductCard
              id={2}
              currency="lei"
              price={87}
              title="JORDAN"
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["new"]}
              sizes={["XL", "S"]}
              text={"bestPrice"}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
            />
            <ProductCard
              id={3}
              currency="lei"
              price={50}
              title="NIKE"
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["new", "2-pack"]}
              icons={"arrows"}
              sizes={["XL", "XS", "L"]}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
            />
            <ProductCard
              id={4}
              currency="lei"
              price={50}
              title="ADIDAS"
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["pont", "new"]}
              sizes={["XL", "XXL"]}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
            />
            <ProductCard
              id={5}
              currency="lei"
              price={50}
              discount={15}
              title="PUMA"
              colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
              badges={["pont"]}
              sizes={["XL", "XS", "S", "M"]}
              primaryImage={primaryImage}
              secondaryImage={secondaryImage}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ locale }) => {
  return {
    props: {
      ...(await serverSideTranslations(locale as string, [
        "common",
        "footer",
        "header",
      ])),
    },
  };
};
