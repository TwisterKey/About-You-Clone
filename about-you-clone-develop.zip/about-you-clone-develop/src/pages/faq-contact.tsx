import clsx from "clsx";
import { GetServerSideProps } from "next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import Link from "next/link";
import { Tile } from "@/components/Elements/Tile/Tile";
import { ChevronRightIcon } from "@heroicons/react/24/outline";

const options = [
  {
    option: "Care este termenul de livrare?",
    transition: "",
  },
  {
    option: "Cum îmi pot urmări comanda?",
    transition: "",
  },
  {
    option: "Cum trimit un retur?",
    transition: "",
  },
  {
    option:
      "Cât timp durează, de regulă, până când primesc înapoi banii pentru retur?",
    transition: "sm:visible md:invisible",
  },
  {
    option: "Este posibilă înlocuirea directă a unui articol returnat?",
    transition: "sm:visible md:invisible",
  },
];

const baseClassNameForOptions =
  "text-black h-20 hover:underline lg:visible sm:w-full lg:w-1/5 ";

export default function FaqContact() {
  const router = useRouter();

  return (
    <div className="min-h-screen p-24">
      <h1 className="text-4xl font-bold mb-4">Întrebări frecvente</h1>
      <div className="flex flex-col justify-between items-center text-sm font-bold space-x-4 md:flex-row">
        {options.map((option, index) => {
          const style = baseClassNameForOptions + option.transition;
          return (
            <div className={style} key={index}>
              <Link
                className={style}
                href={"/faq-contact"}
                locale={router.locale}
              >
                <Tile className="flex flex-row sm:h-20 lg:h-32">
                  <div className="flex items-center">{option.option}</div>
                  <div className="flex items-center">
                    <ChevronRightIcon className="h-3 mt-1 ml-2" />
                  </div>
                </Tile>
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ locale }) => {
  return {
    props: {
      ...(await serverSideTranslations(locale as string, [
        "common",
        "footer",
        "header",
      ])),
    },
  };
};
