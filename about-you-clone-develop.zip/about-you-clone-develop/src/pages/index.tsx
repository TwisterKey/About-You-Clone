import { GetServerSideProps } from "next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import Link from "next/link";
import { primaryImage, secondaryImage } from "@/modules/products/data";
import Carousel from "@/components/Elements/Carousel/Carousel";
import image1 from "/src/components/Elements/Carousel/Images/d196fa5dfe599af2033438938d872583.jpg";
import image2 from "/src/components/Elements/Carousel/Images/662f9034a075ae48a2e64fd4264afc61.jpg";
import image3 from "/src/components/Elements/Carousel/Images/089760b1c82d6d5086b548961287547f.webp";
import image4 from "/src/components/Elements/Carousel/Images/6e620b8d68100ec978baad5f653248a6.webp";
import { Product } from "@/modules/products";
import ProductCard from "@/modules/products/ProductCard";

type MappedProductProps = {
  currency: string;
  price: number;
  title: string;
  colors: string[];
  sizes: string[];
  primaryImage: string;
  secondaryImage: string;
};

type ProductsProps = {
  products: MappedProductProps[];
};

const items = [
  {
    src: image3.src,
    alt: "Slide 1",
    href: "/page1",
  },
  {
    src: image2.src,
    alt: "Slide 2",
    href: "/page2",
  },
  {
    src: image4.src,
    alt: "Slide 3",
    href: "/page3",
  },
  {
    src: image1.src,
    alt: "Slide 4",
    href: "/page4",
  },
];

export default function Home({ products }: ProductsProps) {
  const router = useRouter();
  return (
    <div className="flex min-h-screen flex-col items-center justify-between">
      <div>
        <Carousel items={items} />
      </div>
      <div className="flex min-h-screen flex-col items-center justify-between p-24">
        <div>
          <div className="grid grid-cols-2 gap-4 xl:grid-cols-3 2xl:grid-cols-3 justify-items-center">
            {products.slice(0, 8).map((product, productIndex) => (
              <ProductCard
                key={productIndex}
                currency="lei"
                price={50}
                title={product.title!}
                colors={["#ef4444", "#0c0a09", "#1d4ed8", "#047857"]}
                badges={["pont", "premium"]}
                icons={"shield"}
                sizes={["XL", "XS"]}
                wishlist={true}
                primaryImage={primaryImage}
                secondaryImage={secondaryImage}
                id={0}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="w-full flex flex-col items-center justify-between p-24">
        <Link
          className="text-black p-4 border-1 border-solid border-gray-600 cursor-pointer bg-grey-lightLight "
          href={"/products"}
          locale={router.locale}
        >
          Go to Products
        </Link>
        <Link
          className="bg-white text-black p-4 border-1 border-solid border-gray-600 cursor-pointer"
          href={"/cart"}
          locale={router.locale}
        >
          Cart
        </Link>
      </div>
    </div>
  );
}

function convertData(data: Product[]): MappedProductProps[] {
  return data.map((dataItem) => {
    return {
      currency: "lei",
      price: 0,
      title: dataItem.name,
      colors: ["#ef4444", "#0c0a09", "#1d4ed8", "#047857"],
      sizes: ["XL", "XS", "L"],
      primaryImage: "",
      secondaryImage: "",
    };
  });
}

export const getServerSideProps: GetServerSideProps = async ({ locale }) => {
  const res = await fetch(`https://lsp2023.web-staging.eu/api/products`);
  const data = await res.json();
  const convertedData = convertData(data);

  return {
    props: {
      ...(await serverSideTranslations(locale as string, [
        "common",
        "footer",
        "header",
      ])),
      products: convertedData,
    },
  };
};
