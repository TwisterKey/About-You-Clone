import { ValueOf } from './utils';

export const Breakpoints = {
  XS: 0,
  SM: 480,
  MD: 768,
  LG: 1024,
  XL: 1280,
  XXL: 1440,
} as const;

export type Breakpoint = ValueOf<typeof Breakpoints>;
