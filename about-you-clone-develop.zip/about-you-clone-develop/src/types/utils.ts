export type StringRecord = Record<string, string>;
export type DynamicRecord = Record<string, unknown>;

export type Nullable<T> = T | null;

export type ValueOf<T> = T[keyof T];
