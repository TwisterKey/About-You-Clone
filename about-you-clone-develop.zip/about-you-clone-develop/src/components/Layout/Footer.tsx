import Logo from "../Elements/Logo/Logo";
import { BookmarkSquareIcon } from "@heroicons/react/24/outline";
import { useTranslation } from "next-i18next";
export const Footer = () => {
  const { t } = useTranslation("footer");

  return (
    <footer className="flex flex-col justify-center items-center text-black border-t">
      <section className="flex flex-col items-center w-full py-xl">
        <div className="grid grid-col-1 md:grid-cols-2 lg:grid-cols-3 gap-1 w-7/12 text-xs">
          {/* First col */}
          <div className="flex flex-col p-lg">
            <div className="text-3xl">
              <Logo headerText="you" />
            </div>
          </div>
          {/* Second col */}
          <div className="flex flex-col p-lg font-medium ">
            <h3 className="mb-xl">{t("customerSupport")}</h3>
            <p className="mb-sm">{t("helpAndContact")}</p>
            <p className="mb-sm">{t("collection")}</p>
            <p className="mb-sm">{t("delivery")}</p>
            <p className="mb-sm">{t("consumerProtection")}</p>
          </div>
          {/* Third col */}
          <div className="flex flex-col p-lg font-medium ">
            <h3 className="mb-xl">{t("secure")}</h3>
            <p className="mb-sm">
              <BookmarkSquareIcon className="inline-block h-6 w-6" />
              {t("data")}
            </p>
          </div>
          {/* Fourth col */}
          <div className="flex flex-col p-lg text-grey text-xs ">
            <p className="whitespace-nowrap">{t("freeDelivery")}</p>
            <p className="whitespace-nowrap">{t("bestPrice")}</p>
            <p className="whitespace-nowrap">{t("freeCall")}</p>
            <p className="whitespace-nowrap">{t("tva")}</p>
          </div>
        </div>
      </section>
      <section className="flex flex-col bg-grey-lightLight justify-center items-center w-full px-4 pt-6 pb-3 text-xs ">
        <div className="flex justify-center items-center w-full font-medium ">
          <p className="mx-md">{t("about")}</p>
          <p className="mx-md">{t("press")}</p>
          <p className="mx-md">{t("jobs")}</p>
          <p className="mx-md">{t("investor")}</p>
          <p className="mx-md">{t("privacy")}</p>
          <p className="mx-md">{t("preferences")}</p>
          <p className="mx-md">{t("terms")}</p>
          <p className="mx-md">{t("legal")}</p>
        </div>
        <p className="mt-sm text-grey">&#169; 2023 ABOUT YOU SE & Co. KG</p>
      </section>
    </footer>
  );
};

export default Footer;
