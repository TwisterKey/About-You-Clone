import { TopHeader } from "./TopHeader";
import { MainHeader } from "./MainHeader";
import { Navbar } from "./Navbar";

export const Header = () => {
  return (
    <header className="bg-white text-black text-3xl shadow-md">
      <TopHeader />
      <MainHeader />
      <Navbar />
    </header>
  );
};
export default Header;
