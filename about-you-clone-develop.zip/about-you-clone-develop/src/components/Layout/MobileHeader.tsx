export const MobileHeader = () => {
  return <div className="w-full flex justify-center">Mobile Header</div>;
};
