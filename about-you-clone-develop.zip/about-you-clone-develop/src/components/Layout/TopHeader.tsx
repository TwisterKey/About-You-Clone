import { useTranslation } from "next-i18next";
import clsx from "clsx";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/outline";
import LanguageSwitcher from "../LanguageSwitcher/LanguageSwitcher";
import Link from "next/link";

type TopHeaderProps = JSX.IntrinsicElements["div"];

export const TopHeader = ({
  children,
  className,
  ...props
}: TopHeaderProps) => {
  const { t } = useTranslation("header");
  return (
    <div
      className={clsx(
        "h-8 w-full justify-center bg-slate-100 text-black",
        className
      )}
      {...props}
    >
      {children}
      <div className="mx-14  flow-root">
        <div className="border border-solid h-8 w-fit text-xs float-left text-grey-dark hover:bg-grey-darkerLight flex items-center">
          <Link className="px-1 flex" href="/faq-contact">
            <div className="">
              <QuestionMarkCircleIcon className="h-7 pt-2" />
            </div>
            <div className="">{t("contact")}</div>
          </Link>
        </div>

        <div className=" h-8 border border-solid text-xs float-right text-grey-dark hover:bg-grey-darkerLight ">
          <LanguageSwitcher />
        </div>
      </div>
    </div>
  );
};
