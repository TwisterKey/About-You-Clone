import Header from "./Header";
import Footer from "./Footer";
import React from "react";
import RootModal from "../Elements/LoginAndRegister/RootModal";

interface ILayout {
  children: React.ReactNode;
}

export default function Layout({ children }: ILayout) {
  const myRef = React.useRef(null);
  return (
    <main className="bg-white text-black">
      <Header />
      <div>{children}</div>
      <Footer />
    </main>
  );
}
