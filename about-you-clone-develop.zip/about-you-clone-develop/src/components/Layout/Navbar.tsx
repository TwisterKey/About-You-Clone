import Link from "next/link";
import { Brand } from "../Brands/Brand";
import { ChevronRightIcon } from "@heroicons/react/24/outline";
import SearchComponent from "../SearchComponent/SearchComponent";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useGender } from "@/context/GenderContext";

const navItems = [
  {
    itemName: "Haine",
    subItems: [
      {
        categoryName: "comanda in functie de categorii",
        subItemNames: ["Descopera tot", "Tricouri", "Rochii"],
      },
      {
        categoryName: "cumpara in functie de fit",
        subItemNames: ["Marimi mari", "Petite"],
      },
    ],
    brands: [
      {
        brandName: "Adidas",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANUAAAB4CAMAAABSHEeBAAAAZlBMVEX///8AAACjo6P6+vrk5OQcHBzNzc17e3u1tbWoqKiQkJDo6OgyMjKGhobR0dHt7e3e3t709PQrKytwcHA4ODglJSXY2NhCQkJlZWWWlpZNTU2dnZ3GxsZYWFivr69dXV0ODg4WFhaUTFIJAAAI7klEQVR4nO1cZ5uyOhBdpAjSpSli4f//yZeSZJJAHGHdDd6782n3EWFOysmZgl9ff/Zn/08zI90e/ID5WeDr9uHd5h8Mw9jr9uLN5uVGb/+pNejUxmi1bk/eZ+XeYObqduZddigAlFHHut15h5k3Q7SDbo/eYE1myPbx7G7tJ5gM46Tbq+9ZfGlnQBmPRrdj3zG3nsPUT5ap27XVFlUKTJ3ddDu30vzwoQZlFKlu/1bZ5fgEk/Gp7D6lc2mySt0errEEmSsj0+3hKvMQVMZHsrsZIKjqjySMBpssT7eHa8xECeMj5WDTIrBC3R6ushBbgx8Z7McYquwj5eAOg/WRwX58RVAddXv4upnAbS42WZ/C7qbDR/B3bLISja6+buXJ4Cm7xCbrE9g9Du3e1RYo+4DB2rx2T12a9gPK9lE5qNPjFyzishQgyD+b3YcNxewBHzzJXgxWbVcOpjtb9BUoG9XuZ41+PzPTnUS+ucU+xLS7sc28ezN3KgFlJxiqLRbq0rCd9RW2y1xSmreHo9H9WYuVHAeUHecIrGpj2l2ZczZ4yv4sdk9Oz1yF6pv5BPtg+XYII70gvgJlO9hkbSiViwnyB8zA00ntzN6OdscjeHYpmsq9asQhGZZuaYGyUe2+HXb3MY0HM2BiqO7bSeXK1fmJua9fuqFg//VkeoplZlqdOERDI3igbOdZ7bG3DclBTOPZTLvj7L6dYL98vfrmI1duKZWLCQyOss/Ypdsp1KGUDb0VPqbdA51AvuKzAafLguobmsq96EBDnbvyoW6KsgBsF2yyIC/w25YMB48N2yXCZoBjd+xSTalcn2o/rhUJY3forTCxSw0t2v0Gyg8Iy8JchfMVzcz8fpOd2fBJvxYmC9V4MALoQfDbfVuJlNjbsU9SND8Ll2LKsfpV7Z4KHcG9cbWnd7L7L6ZyTXdmjLlWJIzduVQudqnxa+yezCeJYLJQQb49drdUmfIrEAaq8WAGUHb/DTlo7tQbHELdGJssWK6ozK/m3HivNc9IKwfCWtA5h87rT6dyI2RvA2GhETwk001ssvIfLtRhicwCtsuC3grd2h2NX7lkA1Z9a9kM4Oz+w3JwQXYSHQGO3Vvk0h/uykUTmRxhYSzwgDYM3eyOKleQozE2AlyhDrvr9YfloCz/Jq5C5WOBdtfN7ktqT1j1rWIjgDbZGT+bRsM7Czg5iF0K5xvK7j8sB5Pdc7u44WAHiOAzT3Ht7TBe282Z6hJqnuYiCaV0QKXeFGSXasslvW4Elf0KquAPlVb7Q/WRqMgpoE5/fSKqr+bSU/1FXV/7SFSoaUZlWlGUENViDiZdEJdROQogFFWaRJE/fn8W1fCsVPksv3vSO4bB2l2PhW0Xx/rcIQuPQWc29wZO6mTV0bbtY565Kb+vxksDji3M5FyP97rurDlU/u0eDJ9XYWR+XYr++wXbmPHtlPdPKoKr9724vxR6XrKIEBuLD1OPz9AEu/IJBzZC2BtauYTKEsLSe0O0PMkGxAchdRV+A9dFij2Ko4gqkeV2pUa1lxJqeSuiklPCds6jmiRX87VvbMXKBAxBpRTbU1SJMowcUZnKRqgB1Vwzx0pY6rhnROW2L6N6EhuPqNTdXT2q2V7JYBVtcAmFh7R6BlR8WU26QEZl3pWXjqj4xlXpc4/7uN45ZeTSm63pj4QYPds1zS3kR7tHBZWq6uA27oXnAhkVC+Lbvdc03p7frj2qiCG5n7t7nfmp8aCKTqNHsvIfy5tZTVpkz8vxyPA5iupRsbzzbqSjtAFfJVQs4VKTY4/v0rX4GLsZjyq+3bpDZY0kBVUy8qTl2Sd6Xy66hhpOh8ondz5ykohtRAkVdZqrssFKsKD0z2WTEjZEHuMKm6E428fO7OVVO7K+rvzZzjjPgb/5xsuYrhwRVUpqyEK+ks28xQp5wrvQrPAMqIyKHhNWVHYWLaaLqB3u04r5YEogDku7izuWpmBEVGQAjsLBmdI9b7FOITFooazYr0DWclJlbhmnq3NO3pzTX5FNUZnjX620Ya9zqMi0SOuFTrZFF6D02gFNgXiT3ow8uzTrxODoyUOO+SqKyh/3mNzxdptBRbjAlva2b1NUZATl6kfAUM3kTKv9Gsk0zv/kvdATRUXW2k76PJlBRXh5Uoli6vbMZlWwA6CaLaFfli/EEdXk+GbqtplHNRfhE1ST7gmG6jCPile38Zy4WN7HOqKa/KQLmyuyF+RVM6fZyQqczNURmas9h6qT7NIbeL0tFheK8WP7Kp7fV54alfwrWbCvyK6RT58jj6oP9DK5+65dyhnEPSnDTUtojAPlV/bqGVQKDqQMYNEJzpUcSMy0Si8UkMkbALOEcThnrNzpML0gVgIpW4uoaBOQsJwtKiO78SaaRVzOVJBMWvbNZk8Gd3lZgYy6sMdZl5gDrvJrlHkqoqLzKugUJv0stoNaHvaNyrMO1fnQWwhJODp6i1HRL95h7UIfhQMR0wOe5bM2A0kHUnWUMcJIIZ6yQBEFzeTxAypytsOrJmm9EhUL1IrbgMvk0w79umQn4z4a5sDaQWAka3YqVQN32IdpwxG1xWuHy3hARpyY8JjSht59i9xwubyF0apO4SG7tvCgAZXJ4qvivj/sT3z8JcdX0OBYZ2GYCUF2P2YJo+3g1N+L7y3xQNOzCi0d4BW11Se9lgOHpDMniALVs0L9sBKedBV6/Nf3TpmU7JcLVnU5qeulIzM2SlgTVKm6TDzuW3UzR4+KTyZwD11VBk+VKRLC944K1jTHFCt7YAgbKV+59ZRzubZc7EnNU0UuoJq+TzsbiYx2aMVLK6YtRmukNNSj4lDB7xmDrVC3xMTfPT3RLmLGwKmQEny4lKMBFRB/JJDEPpbrwrGwCuuI/Ev0QywtnPpbLTPm7lQHhR3Up3PHQO54HvL6q8yuVWEfq+u+6RuNBzv37bnjn/zJ6p/vdWAXeX3yunG+jBfwmss91bltB9X90D2hCYdnQTLT7Z50tO2i6nz5foNdXDpO+eQ2qRU5kfVS94Dpd/dKnmS8xmep1lZqdR9H1nZe//6zP5u1f/t5cbwvXJxIAAAAAElFTkSuQmCC",
      },
      {
        brandName: "Nike",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABHCAMAAAB1YPihAAAAZlBMVEX///8AAADs7Oz5+fnV1dWenp69vb3x8fH29vbY2Njo6OiHh4fi4uI+Pj4iIiLNzc04ODi0tLTDw8OOjo4YGBhXV1d9fX2kpKRxcXFeXl5paWksLCxOTk4yMjJkZGQTExNHR0eWlpYuKdFeAAADpklEQVRogdWb2YKrIAyGB/fdolW0dvP9X3KcemylRXao57sdDImF/CE4Pz8UPNof/yNG59se8BKXNFeRb80RFZKgTT2XMqAE1nyRJvTGQ55m1DExgJa8kSTKUD+AHIb0Ycltzz+I68AuBwCcStbIcADIhkcyRFV6noIAxZgwx7rTSAsuSVDWDXiQQ9oGXzgBUBv3SZgYXcE/Oj6Ja6eh9FRgnQyeliDAcYz4HvKnwXeTXgkyKcXtGQVoAt7ngr/he8m9TlkfVlGANuZ+NHtkBHZCME/o+U2xCgIcRoZorHEf8Z/NucfHJHfXA8BoKs6tMTNnt6+KyCJ3a46tYClez8/xr0TdLHKHUSDRQjyYH7x8qYAvx+YjiCmDcuepJ9myHA04yZwb9YQghPLUE3fZXq1+P6lksCMGAQbEU4h80C7P29zrk9wdyVGAayVnEj4tSBoQZpK7/LYRxbGVrZKS14ux0XX4k7thI4hpgwvnqRerhGE6+0YZfJc7jL6S2hozcGXIZCCuE7R3ShCgkF5TD8K1LWNLyy0JcocxIIF6isRpbc3MZveIcve2plQnKTF7+jta2et0t02qoea+YBZP6gZXbModxkWLeCHc6F0haeAkQbold/irYzZ2uIiKN7ta0pZTjjlXFIOONfXAfzet3EMJY0SRO4wzq1koMOv7DwIKFdtuAk80ucO46llTM+jT/ihriyV3+PuqtXadItLrk5mBLXcYByh0CGcTkGbJRa14PvlgtIXWNTVDfou9gAUuucMwcRsWb8zVcQbBJXcYZzPtv3prvp6ZupKq/Uh4TDpTtfV2uh9o7Yu/0x2X3GFcam2i8Y5Hm3eju0c/3VHM6c5Taz5UHSdvS2c1e+RkQdpf6M+QOXJeasjy3pwkBXPt0rqu07brOUaTKXzTfXFZz4TIzV9TULeIJgyvqRnI9kMR3+AGX7GpInrgvyhT5cR2Rh61xo4Y/DW3KLlv9XJCvMTgo1FpFspgJIqjsXrKaiAX9I074a2uvjRna3kKR7rmICNzUaYHnem3+Oat9qgtDPUGtBLEzoM4N8aXheZxdIRxV73U0IH6br+WlrWPjGL5W6Tf+9wDx1UpUg57WFML8j9Jo79ZqIRIv3aF3ga0DhKJKCwcwiWoRMOwcgiXQUgVc5EvC23DHUnR7UM0Nol5OqDHHu7/f2OilhFF0cA9fEPLQUa55xjaav+/xYsEkW4ThxTuTjHYhBVqz/O1xy2/pijYSyXF4hfGjyxkm9TyZQAAAABJRU5ErkJggg==",
      },
    ],
  },
  {
    itemName: "Pantofi",
    subItems: [
      {
        categoryName: "comanda in functie de categorii",
        subItemNames: ["Descopera tot", "Sneakers", "Sandale"],
      },
      {
        categoryName: "cumpara in functie de fit",
        subItemNames: ["Marimi mari", "Petite"],
      },
    ],
    brands: [
      {
        brandName: "Adidas",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANUAAAB4CAMAAABSHEeBAAAAZlBMVEX///8AAACjo6P6+vrk5OQcHBzNzc17e3u1tbWoqKiQkJDo6OgyMjKGhobR0dHt7e3e3t709PQrKytwcHA4ODglJSXY2NhCQkJlZWWWlpZNTU2dnZ3GxsZYWFivr69dXV0ODg4WFhaUTFIJAAAI7klEQVR4nO1cZ5uyOhBdpAjSpSli4f//yZeSZJJAHGHdDd6782n3EWFOysmZgl9ff/Zn/08zI90e/ID5WeDr9uHd5h8Mw9jr9uLN5uVGb/+pNejUxmi1bk/eZ+XeYObqduZddigAlFHHut15h5k3Q7SDbo/eYE1myPbx7G7tJ5gM46Tbq+9ZfGlnQBmPRrdj3zG3nsPUT5ap27XVFlUKTJ3ddDu30vzwoQZlFKlu/1bZ5fgEk/Gp7D6lc2mySt0errEEmSsj0+3hKvMQVMZHsrsZIKjqjySMBpssT7eHa8xECeMj5WDTIrBC3R6ushBbgx8Z7McYquwj5eAOg/WRwX58RVAddXv4upnAbS42WZ/C7qbDR/B3bLISja6+buXJ4Cm7xCbrE9g9Du3e1RYo+4DB2rx2T12a9gPK9lE5qNPjFyzishQgyD+b3YcNxewBHzzJXgxWbVcOpjtb9BUoG9XuZ41+PzPTnUS+ucU+xLS7sc28ezN3KgFlJxiqLRbq0rCd9RW2y1xSmreHo9H9WYuVHAeUHecIrGpj2l2ZczZ4yv4sdk9Oz1yF6pv5BPtg+XYII70gvgJlO9hkbSiViwnyB8zA00ntzN6OdscjeHYpmsq9asQhGZZuaYGyUe2+HXb3MY0HM2BiqO7bSeXK1fmJua9fuqFg//VkeoplZlqdOERDI3igbOdZ7bG3DclBTOPZTLvj7L6dYL98vfrmI1duKZWLCQyOss/Ypdsp1KGUDb0VPqbdA51AvuKzAafLguobmsq96EBDnbvyoW6KsgBsF2yyIC/w25YMB48N2yXCZoBjd+xSTalcn2o/rhUJY3forTCxSw0t2v0Gyg8Iy8JchfMVzcz8fpOd2fBJvxYmC9V4MALoQfDbfVuJlNjbsU9SND8Ll2LKsfpV7Z4KHcG9cbWnd7L7L6ZyTXdmjLlWJIzduVQudqnxa+yezCeJYLJQQb49drdUmfIrEAaq8WAGUHb/DTlo7tQbHELdGJssWK6ozK/m3HivNc9IKwfCWtA5h87rT6dyI2RvA2GhETwk001ssvIfLtRhicwCtsuC3grd2h2NX7lkA1Z9a9kM4Oz+w3JwQXYSHQGO3Vvk0h/uykUTmRxhYSzwgDYM3eyOKleQozE2AlyhDrvr9YfloCz/Jq5C5WOBdtfN7ktqT1j1rWIjgDbZGT+bRsM7Czg5iF0K5xvK7j8sB5Pdc7u44WAHiOAzT3Ht7TBe282Z6hJqnuYiCaV0QKXeFGSXasslvW4Elf0KquAPlVb7Q/WRqMgpoE5/fSKqr+bSU/1FXV/7SFSoaUZlWlGUENViDiZdEJdROQogFFWaRJE/fn8W1fCsVPksv3vSO4bB2l2PhW0Xx/rcIQuPQWc29wZO6mTV0bbtY565Kb+vxksDji3M5FyP97rurDlU/u0eDJ9XYWR+XYr++wXbmPHtlPdPKoKr9724vxR6XrKIEBuLD1OPz9AEu/IJBzZC2BtauYTKEsLSe0O0PMkGxAchdRV+A9dFij2Ko4gqkeV2pUa1lxJqeSuiklPCds6jmiRX87VvbMXKBAxBpRTbU1SJMowcUZnKRqgB1Vwzx0pY6rhnROW2L6N6EhuPqNTdXT2q2V7JYBVtcAmFh7R6BlR8WU26QEZl3pWXjqj4xlXpc4/7uN45ZeTSm63pj4QYPds1zS3kR7tHBZWq6uA27oXnAhkVC+Lbvdc03p7frj2qiCG5n7t7nfmp8aCKTqNHsvIfy5tZTVpkz8vxyPA5iupRsbzzbqSjtAFfJVQs4VKTY4/v0rX4GLsZjyq+3bpDZY0kBVUy8qTl2Sd6Xy66hhpOh8ondz5ykohtRAkVdZqrssFKsKD0z2WTEjZEHuMKm6E428fO7OVVO7K+rvzZzjjPgb/5xsuYrhwRVUpqyEK+ks28xQp5wrvQrPAMqIyKHhNWVHYWLaaLqB3u04r5YEogDku7izuWpmBEVGQAjsLBmdI9b7FOITFooazYr0DWclJlbhmnq3NO3pzTX5FNUZnjX620Ya9zqMi0SOuFTrZFF6D02gFNgXiT3ow8uzTrxODoyUOO+SqKyh/3mNzxdptBRbjAlva2b1NUZATl6kfAUM3kTKv9Gsk0zv/kvdATRUXW2k76PJlBRXh5Uoli6vbMZlWwA6CaLaFfli/EEdXk+GbqtplHNRfhE1ST7gmG6jCPile38Zy4WN7HOqKa/KQLmyuyF+RVM6fZyQqczNURmas9h6qT7NIbeL0tFheK8WP7Kp7fV54alfwrWbCvyK6RT58jj6oP9DK5+65dyhnEPSnDTUtojAPlV/bqGVQKDqQMYNEJzpUcSMy0Si8UkMkbALOEcThnrNzpML0gVgIpW4uoaBOQsJwtKiO78SaaRVzOVJBMWvbNZk8Gd3lZgYy6sMdZl5gDrvJrlHkqoqLzKugUJv0stoNaHvaNyrMO1fnQWwhJODp6i1HRL95h7UIfhQMR0wOe5bM2A0kHUnWUMcJIIZ6yQBEFzeTxAypytsOrJmm9EhUL1IrbgMvk0w79umQn4z4a5sDaQWAka3YqVQN32IdpwxG1xWuHy3hARpyY8JjSht59i9xwubyF0apO4SG7tvCgAZXJ4qvivj/sT3z8JcdX0OBYZ2GYCUF2P2YJo+3g1N+L7y3xQNOzCi0d4BW11Se9lgOHpDMniALVs0L9sBKedBV6/Nf3TpmU7JcLVnU5qeulIzM2SlgTVKm6TDzuW3UzR4+KTyZwD11VBk+VKRLC944K1jTHFCt7YAgbKV+59ZRzubZc7EnNU0UuoJq+TzsbiYx2aMVLK6YtRmukNNSj4lDB7xmDrVC3xMTfPT3RLmLGwKmQEny4lKMBFRB/JJDEPpbrwrGwCuuI/Ev0QywtnPpbLTPm7lQHhR3Up3PHQO54HvL6q8yuVWEfq+u+6RuNBzv37bnjn/zJ6p/vdWAXeX3yunG+jBfwmss91bltB9X90D2hCYdnQTLT7Z50tO2i6nz5foNdXDpO+eQ2qRU5kfVS94Dpd/dKnmS8xmep1lZqdR9H1nZe//6zP5u1f/t5cbwvXJxIAAAAAElFTkSuQmCC",
      },
      {
        brandName: "Nike",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABHCAMAAAB1YPihAAAAZlBMVEX///8AAADs7Oz5+fnV1dWenp69vb3x8fH29vbY2Njo6OiHh4fi4uI+Pj4iIiLNzc04ODi0tLTDw8OOjo4YGBhXV1d9fX2kpKRxcXFeXl5paWksLCxOTk4yMjJkZGQTExNHR0eWlpYuKdFeAAADpklEQVRogdWb2YKrIAyGB/fdolW0dvP9X3KcemylRXao57sdDImF/CE4Pz8UPNof/yNG59se8BKXNFeRb80RFZKgTT2XMqAE1nyRJvTGQ55m1DExgJa8kSTKUD+AHIb0Ycltzz+I68AuBwCcStbIcADIhkcyRFV6noIAxZgwx7rTSAsuSVDWDXiQQ9oGXzgBUBv3SZgYXcE/Oj6Ja6eh9FRgnQyeliDAcYz4HvKnwXeTXgkyKcXtGQVoAt7ngr/he8m9TlkfVlGANuZ+NHtkBHZCME/o+U2xCgIcRoZorHEf8Z/NucfHJHfXA8BoKs6tMTNnt6+KyCJ3a46tYClez8/xr0TdLHKHUSDRQjyYH7x8qYAvx+YjiCmDcuepJ9myHA04yZwb9YQghPLUE3fZXq1+P6lksCMGAQbEU4h80C7P29zrk9wdyVGAayVnEj4tSBoQZpK7/LYRxbGVrZKS14ux0XX4k7thI4hpgwvnqRerhGE6+0YZfJc7jL6S2hozcGXIZCCuE7R3ShCgkF5TD8K1LWNLyy0JcocxIIF6isRpbc3MZveIcve2plQnKTF7+jta2et0t02qoea+YBZP6gZXbModxkWLeCHc6F0haeAkQbold/irYzZ2uIiKN7ta0pZTjjlXFIOONfXAfzet3EMJY0SRO4wzq1koMOv7DwIKFdtuAk80ucO46llTM+jT/ihriyV3+PuqtXadItLrk5mBLXcYByh0CGcTkGbJRa14PvlgtIXWNTVDfou9gAUuucMwcRsWb8zVcQbBJXcYZzPtv3prvp6ZupKq/Uh4TDpTtfV2uh9o7Yu/0x2X3GFcam2i8Y5Hm3eju0c/3VHM6c5Taz5UHSdvS2c1e+RkQdpf6M+QOXJeasjy3pwkBXPt0rqu07brOUaTKXzTfXFZz4TIzV9TULeIJgyvqRnI9kMR3+AGX7GpInrgvyhT5cR2Rh61xo4Y/DW3KLlv9XJCvMTgo1FpFspgJIqjsXrKaiAX9I074a2uvjRna3kKR7rmICNzUaYHnem3+Oat9qgtDPUGtBLEzoM4N8aXheZxdIRxV73U0IH6br+WlrWPjGL5W6Tf+9wDx1UpUg57WFML8j9Jo79ZqIRIv3aF3ga0DhKJKCwcwiWoRMOwcgiXQUgVc5EvC23DHUnR7UM0Nol5OqDHHu7/f2OilhFF0cA9fEPLQUa55xjaav+/xYsEkW4ThxTuTjHYhBVqz/O1xy2/pijYSyXF4hfGjyxkm9TyZQAAAABJRU5ErkJggg==",
      },
    ],
  },
  {
    itemName: "Branduri",
    subItems: [],
    brands: [
      {
        brandName: "Adidas",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANUAAAB4CAMAAABSHEeBAAAAZlBMVEX///8AAACjo6P6+vrk5OQcHBzNzc17e3u1tbWoqKiQkJDo6OgyMjKGhobR0dHt7e3e3t709PQrKytwcHA4ODglJSXY2NhCQkJlZWWWlpZNTU2dnZ3GxsZYWFivr69dXV0ODg4WFhaUTFIJAAAI7klEQVR4nO1cZ5uyOhBdpAjSpSli4f//yZeSZJJAHGHdDd6782n3EWFOysmZgl9ff/Zn/08zI90e/ID5WeDr9uHd5h8Mw9jr9uLN5uVGb/+pNejUxmi1bk/eZ+XeYObqduZddigAlFHHut15h5k3Q7SDbo/eYE1myPbx7G7tJ5gM46Tbq+9ZfGlnQBmPRrdj3zG3nsPUT5ap27XVFlUKTJ3ddDu30vzwoQZlFKlu/1bZ5fgEk/Gp7D6lc2mySt0errEEmSsj0+3hKvMQVMZHsrsZIKjqjySMBpssT7eHa8xECeMj5WDTIrBC3R6ushBbgx8Z7McYquwj5eAOg/WRwX58RVAddXv4upnAbS42WZ/C7qbDR/B3bLISja6+buXJ4Cm7xCbrE9g9Du3e1RYo+4DB2rx2T12a9gPK9lE5qNPjFyzishQgyD+b3YcNxewBHzzJXgxWbVcOpjtb9BUoG9XuZ41+PzPTnUS+ucU+xLS7sc28ezN3KgFlJxiqLRbq0rCd9RW2y1xSmreHo9H9WYuVHAeUHecIrGpj2l2ZczZ4yv4sdk9Oz1yF6pv5BPtg+XYII70gvgJlO9hkbSiViwnyB8zA00ntzN6OdscjeHYpmsq9asQhGZZuaYGyUe2+HXb3MY0HM2BiqO7bSeXK1fmJua9fuqFg//VkeoplZlqdOERDI3igbOdZ7bG3DclBTOPZTLvj7L6dYL98vfrmI1duKZWLCQyOss/Ypdsp1KGUDb0VPqbdA51AvuKzAafLguobmsq96EBDnbvyoW6KsgBsF2yyIC/w25YMB48N2yXCZoBjd+xSTalcn2o/rhUJY3forTCxSw0t2v0Gyg8Iy8JchfMVzcz8fpOd2fBJvxYmC9V4MALoQfDbfVuJlNjbsU9SND8Ll2LKsfpV7Z4KHcG9cbWnd7L7L6ZyTXdmjLlWJIzduVQudqnxa+yezCeJYLJQQb49drdUmfIrEAaq8WAGUHb/DTlo7tQbHELdGJssWK6ozK/m3HivNc9IKwfCWtA5h87rT6dyI2RvA2GhETwk001ssvIfLtRhicwCtsuC3grd2h2NX7lkA1Z9a9kM4Oz+w3JwQXYSHQGO3Vvk0h/uykUTmRxhYSzwgDYM3eyOKleQozE2AlyhDrvr9YfloCz/Jq5C5WOBdtfN7ktqT1j1rWIjgDbZGT+bRsM7Czg5iF0K5xvK7j8sB5Pdc7u44WAHiOAzT3Ht7TBe282Z6hJqnuYiCaV0QKXeFGSXasslvW4Elf0KquAPlVb7Q/WRqMgpoE5/fSKqr+bSU/1FXV/7SFSoaUZlWlGUENViDiZdEJdROQogFFWaRJE/fn8W1fCsVPksv3vSO4bB2l2PhW0Xx/rcIQuPQWc29wZO6mTV0bbtY565Kb+vxksDji3M5FyP97rurDlU/u0eDJ9XYWR+XYr++wXbmPHtlPdPKoKr9724vxR6XrKIEBuLD1OPz9AEu/IJBzZC2BtauYTKEsLSe0O0PMkGxAchdRV+A9dFij2Ko4gqkeV2pUa1lxJqeSuiklPCds6jmiRX87VvbMXKBAxBpRTbU1SJMowcUZnKRqgB1Vwzx0pY6rhnROW2L6N6EhuPqNTdXT2q2V7JYBVtcAmFh7R6BlR8WU26QEZl3pWXjqj4xlXpc4/7uN45ZeTSm63pj4QYPds1zS3kR7tHBZWq6uA27oXnAhkVC+Lbvdc03p7frj2qiCG5n7t7nfmp8aCKTqNHsvIfy5tZTVpkz8vxyPA5iupRsbzzbqSjtAFfJVQs4VKTY4/v0rX4GLsZjyq+3bpDZY0kBVUy8qTl2Sd6Xy66hhpOh8ondz5ykohtRAkVdZqrssFKsKD0z2WTEjZEHuMKm6E428fO7OVVO7K+rvzZzjjPgb/5xsuYrhwRVUpqyEK+ks28xQp5wrvQrPAMqIyKHhNWVHYWLaaLqB3u04r5YEogDku7izuWpmBEVGQAjsLBmdI9b7FOITFooazYr0DWclJlbhmnq3NO3pzTX5FNUZnjX620Ya9zqMi0SOuFTrZFF6D02gFNgXiT3ow8uzTrxODoyUOO+SqKyh/3mNzxdptBRbjAlva2b1NUZATl6kfAUM3kTKv9Gsk0zv/kvdATRUXW2k76PJlBRXh5Uoli6vbMZlWwA6CaLaFfli/EEdXk+GbqtplHNRfhE1ST7gmG6jCPile38Zy4WN7HOqKa/KQLmyuyF+RVM6fZyQqczNURmas9h6qT7NIbeL0tFheK8WP7Kp7fV54alfwrWbCvyK6RT58jj6oP9DK5+65dyhnEPSnDTUtojAPlV/bqGVQKDqQMYNEJzpUcSMy0Si8UkMkbALOEcThnrNzpML0gVgIpW4uoaBOQsJwtKiO78SaaRVzOVJBMWvbNZk8Gd3lZgYy6sMdZl5gDrvJrlHkqoqLzKugUJv0stoNaHvaNyrMO1fnQWwhJODp6i1HRL95h7UIfhQMR0wOe5bM2A0kHUnWUMcJIIZ6yQBEFzeTxAypytsOrJmm9EhUL1IrbgMvk0w79umQn4z4a5sDaQWAka3YqVQN32IdpwxG1xWuHy3hARpyY8JjSht59i9xwubyF0apO4SG7tvCgAZXJ4qvivj/sT3z8JcdX0OBYZ2GYCUF2P2YJo+3g1N+L7y3xQNOzCi0d4BW11Se9lgOHpDMniALVs0L9sBKedBV6/Nf3TpmU7JcLVnU5qeulIzM2SlgTVKm6TDzuW3UzR4+KTyZwD11VBk+VKRLC944K1jTHFCt7YAgbKV+59ZRzubZc7EnNU0UuoJq+TzsbiYx2aMVLK6YtRmukNNSj4lDB7xmDrVC3xMTfPT3RLmLGwKmQEny4lKMBFRB/JJDEPpbrwrGwCuuI/Ev0QywtnPpbLTPm7lQHhR3Up3PHQO54HvL6q8yuVWEfq+u+6RuNBzv37bnjn/zJ6p/vdWAXeX3yunG+jBfwmss91bltB9X90D2hCYdnQTLT7Z50tO2i6nz5foNdXDpO+eQ2qRU5kfVS94Dpd/dKnmS8xmep1lZqdR9H1nZe//6zP5u1f/t5cbwvXJxIAAAAAElFTkSuQmCC",
      },
      {
        brandName: "Nike",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABHCAMAAAB1YPihAAAAZlBMVEX///8AAADs7Oz5+fnV1dWenp69vb3x8fH29vbY2Njo6OiHh4fi4uI+Pj4iIiLNzc04ODi0tLTDw8OOjo4YGBhXV1d9fX2kpKRxcXFeXl5paWksLCxOTk4yMjJkZGQTExNHR0eWlpYuKdFeAAADpklEQVRogdWb2YKrIAyGB/fdolW0dvP9X3KcemylRXao57sdDImF/CE4Pz8UPNof/yNG59se8BKXNFeRb80RFZKgTT2XMqAE1nyRJvTGQ55m1DExgJa8kSTKUD+AHIb0Ycltzz+I68AuBwCcStbIcADIhkcyRFV6noIAxZgwx7rTSAsuSVDWDXiQQ9oGXzgBUBv3SZgYXcE/Oj6Ja6eh9FRgnQyeliDAcYz4HvKnwXeTXgkyKcXtGQVoAt7ngr/he8m9TlkfVlGANuZ+NHtkBHZCME/o+U2xCgIcRoZorHEf8Z/NucfHJHfXA8BoKs6tMTNnt6+KyCJ3a46tYClez8/xr0TdLHKHUSDRQjyYH7x8qYAvx+YjiCmDcuepJ9myHA04yZwb9YQghPLUE3fZXq1+P6lksCMGAQbEU4h80C7P29zrk9wdyVGAayVnEj4tSBoQZpK7/LYRxbGVrZKS14ux0XX4k7thI4hpgwvnqRerhGE6+0YZfJc7jL6S2hozcGXIZCCuE7R3ShCgkF5TD8K1LWNLyy0JcocxIIF6isRpbc3MZveIcve2plQnKTF7+jta2et0t02qoea+YBZP6gZXbModxkWLeCHc6F0haeAkQbold/irYzZ2uIiKN7ta0pZTjjlXFIOONfXAfzet3EMJY0SRO4wzq1koMOv7DwIKFdtuAk80ucO46llTM+jT/ihriyV3+PuqtXadItLrk5mBLXcYByh0CGcTkGbJRa14PvlgtIXWNTVDfou9gAUuucMwcRsWb8zVcQbBJXcYZzPtv3prvp6ZupKq/Uh4TDpTtfV2uh9o7Yu/0x2X3GFcam2i8Y5Hm3eju0c/3VHM6c5Taz5UHSdvS2c1e+RkQdpf6M+QOXJeasjy3pwkBXPt0rqu07brOUaTKXzTfXFZz4TIzV9TULeIJgyvqRnI9kMR3+AGX7GpInrgvyhT5cR2Rh61xo4Y/DW3KLlv9XJCvMTgo1FpFspgJIqjsXrKaiAX9I074a2uvjRna3kKR7rmICNzUaYHnem3+Oat9qgtDPUGtBLEzoM4N8aXheZxdIRxV73U0IH6br+WlrWPjGL5W6Tf+9wDx1UpUg57WFML8j9Jo79ZqIRIv3aF3ga0DhKJKCwcwiWoRMOwcgiXQUgVc5EvC23DHUnR7UM0Nol5OqDHHu7/f2OilhFF0cA9fEPLQUa55xjaav+/xYsEkW4ThxTuTjHYhBVqz/O1xy2/pijYSyXF4hfGjyxkm9TyZQAAAABJRU5ErkJggg==",
      },
      {
        brandName: "Nike",
        image:
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABHCAMAAAB1YPihAAAAZlBMVEX///8AAADs7Oz5+fnV1dWenp69vb3x8fH29vbY2Njo6OiHh4fi4uI+Pj4iIiLNzc04ODi0tLTDw8OOjo4YGBhXV1d9fX2kpKRxcXFeXl5paWksLCxOTk4yMjJkZGQTExNHR0eWlpYuKdFeAAADpklEQVRogdWb2YKrIAyGB/fdolW0dvP9X3KcemylRXao57sdDImF/CE4Pz8UPNof/yNG59se8BKXNFeRb80RFZKgTT2XMqAE1nyRJvTGQ55m1DExgJa8kSTKUD+AHIb0Ycltzz+I68AuBwCcStbIcADIhkcyRFV6noIAxZgwx7rTSAsuSVDWDXiQQ9oGXzgBUBv3SZgYXcE/Oj6Ja6eh9FRgnQyeliDAcYz4HvKnwXeTXgkyKcXtGQVoAt7ngr/he8m9TlkfVlGANuZ+NHtkBHZCME/o+U2xCgIcRoZorHEf8Z/NucfHJHfXA8BoKs6tMTNnt6+KyCJ3a46tYClez8/xr0TdLHKHUSDRQjyYH7x8qYAvx+YjiCmDcuepJ9myHA04yZwb9YQghPLUE3fZXq1+P6lksCMGAQbEU4h80C7P29zrk9wdyVGAayVnEj4tSBoQZpK7/LYRxbGVrZKS14ux0XX4k7thI4hpgwvnqRerhGE6+0YZfJc7jL6S2hozcGXIZCCuE7R3ShCgkF5TD8K1LWNLyy0JcocxIIF6isRpbc3MZveIcve2plQnKTF7+jta2et0t02qoea+YBZP6gZXbModxkWLeCHc6F0haeAkQbold/irYzZ2uIiKN7ta0pZTjjlXFIOONfXAfzet3EMJY0SRO4wzq1koMOv7DwIKFdtuAk80ucO46llTM+jT/ihriyV3+PuqtXadItLrk5mBLXcYByh0CGcTkGbJRa14PvlgtIXWNTVDfou9gAUuucMwcRsWb8zVcQbBJXcYZzPtv3prvp6ZupKq/Uh4TDpTtfV2uh9o7Yu/0x2X3GFcam2i8Y5Hm3eju0c/3VHM6c5Taz5UHSdvS2c1e+RkQdpf6M+QOXJeasjy3pwkBXPt0rqu07brOUaTKXzTfXFZz4TIzV9TULeIJgyvqRnI9kMR3+AGX7GpInrgvyhT5cR2Rh61xo4Y/DW3KLlv9XJCvMTgo1FpFspgJIqjsXrKaiAX9I074a2uvjRna3kKR7rmICNzUaYHnem3+Oat9qgtDPUGtBLEzoM4N8aXheZxdIRxV73U0IH6br+WlrWPjGL5W6Tf+9wDx1UpUg57WFML8j9Jo79ZqIRIv3aF3ga0DhKJKCwcwiWoRMOwcgiXQUgVc5EvC23DHUnR7UM0Nol5OqDHHu7/f2OilhFF0cA9fEPLQUa55xjaav+/xYsEkW4ThxTuTjHYhBVqz/O1xy2/pijYSyXF4hfGjyxkm9TyZQAAAABJRU5ErkJggg==",
      },
    ],
  },
];
export const Navbar = () => {
  const router = useRouter();
  const { gender } = useGender();

  return (
    <>
      <nav className="w-full flex px-14 justify-between flex-col md:flex-row">
        <div className="flex-row flex">
          {navItems.map((item, index) => {
            const subItems = item.subItems;
            const brands = item.brands;
            return (
              <div className="group/navitem px-2" key={index}>
                <div className="px-2 text-sm h-12 grid place-items-center group">
                  <a className="flex flex-row items-center justify-center py-1 px-1 hover:bg-grey-lightLight cursor-pointer rounded-sm select-none z-0">
                    {item.itemName}
                  </a>
                </div>
                <div className="absolute hidden bg-grey-200 group-hover/navitem:block group-hover/navitem:w-full group-hover/navitem:left-0 bg-white z-30">
                  <div className="px-16 pt-2 pb-2 shadow-lg w-full">
                    <div className="flex gap-4 align-center mt-2 px-1.5">
                      {subItems.map((subItem, subItemIndex) => {
                        return (
                          <ul className="text-sm" key={subItemIndex}>
                            <p className="text-sm uppercase font-bold text-gray-500 mb-2">
                              {subItem.categoryName}
                            </p>
                            {subItem.subItemNames.map(
                              (thisSubItem, subItemIndex) => {
                                return (
                                  <li
                                    className="text-sm select-none group/chevron flex"
                                    key={subItemIndex}
                                  >
                                    <button
                                      type="button"
                                      onClick={() =>
                                        router.push(
                                          `/products/${gender}/${encodeURI(
                                            thisSubItem.toLocaleLowerCase()
                                          )}` as any,
                                          undefined,
                                          { shallow: true }
                                        )
                                      }
                                    >
                                      {thisSubItem}
                                    </button>
                                    {/* <Link  href={{
                                            pathname: `/products/${gender}/${encodeURI(thisSubItem.toLocaleLowerCase())}`,
                                            query: {  },
                                          }}>
                                          {thisSubItem}
                                        </Link>         */}
                                    <div className="invisible group-hover/chevron:visible ml-1">
                                      <ChevronRightIcon className="h-3 inline-block align-middle" />
                                    </div>
                                  </li>
                                );
                              }
                            )}
                          </ul>
                        );
                      })}
                      <div>
                        <p className="text-sm uppercase font-bold text-gray-500 mb-2">
                          Brands
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          {brands.map((subItem, subItemIndex) => {
                            return (
                              <div
                                className="text-sm flex justify-center items-center cursor-pointer select-none"
                                key={subItemIndex}
                              >
                                <Brand
                                  title={subItem.brandName}
                                  src={subItem.image}
                                  height={70}
                                  width={70}
                                ></Brand>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <SearchComponent />
      </nav>
    </>
  );
};
