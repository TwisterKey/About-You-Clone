import Logo from "../Elements/Logo/Logo";
import { useState } from "react";
import ToolbarActions from "../Elements/ToolbarActions/ToolbarActions";
import GenderSwitcher from "../GenderSwitcher/GenderSwitcher";
import { useTranslation } from "next-i18next";
import { useScreenSize } from "@/hooks/useScreenSize";
import { Breakpoints } from "@/types/layout";

export const MainHeader = () => {
  const { isAbove } = useScreenSize();
  const { t } = useTranslation("header");
  const [headerText, setHeaderText] = useState("");
  const [logoKey, setLogoKey] = useState(0);
  const handleTextChange = (text: string) => {
    setHeaderText(text);
    setLogoKey((prevKey) => prevKey + 1);
  };

  return (
    <div className={`${!isAbove(Breakpoints.LG) ? "hidden" : ""}`}>
      <div className="py-8 px-4 h-11 flex justify-between items-center bg-white text-black text-3xl mb-2">
        <GenderSwitcher />
        <Logo
          headerText={headerText ? headerText.toUpperCase() : ""}
          key={logoKey}
        ></Logo>

        <ToolbarActions />
      </div>
    </div>
  );
};

export default MainHeader;
