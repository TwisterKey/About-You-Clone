import * as Popover from "@/components/Elements/Popover";
import { HamburgerMenuIcon } from "@radix-ui/react-icons";
import useLocalStorage from "@/hooks/useLocalStorage";
import { useTranslation } from "next-i18next";
import { useRouter } from "next/router";
import Image from "next/image";
import { useState } from "react";

const LanguageSwitcher = () => {
  const [language, setLanguage] = useLocalStorage("language", "ro");
  const [languageTag, setLanguageTag] = useState({
    language: "RO",
    flag: "http://purecatamphetamine.github.io/country-flag-icons/3x2/RO.svg",
  });
  const router = useRouter();
  const { i18n } = useTranslation();

  const handleLanguageChange = (language: any) => {
    i18n.changeLanguage(language);
    setLanguage(language);
    router.push(router.pathname as any, router.asPath, { locale: language });
    switch (language) {
      case "ro": {
        setLanguageTag({
          language: "RO",
          flag: "http://purecatamphetamine.github.io/country-flag-icons/3x2/RO.svg",
        });
        break;
      }
      case "en": {
        setLanguageTag({
          language: "EN",
          flag: "http://purecatamphetamine.github.io/country-flag-icons/3x2/US.svg",
        });
        break;
      }
    }
  };

  return (
    <Popover.Root>
      <Popover.Trigger asChild className=" px-1">
        <button className="grid grid-cols-2 items-center h-8 bg-inherit">
          <p className="text-xs ">{languageTag.language}</p>
          <Image
            alt="Romania"
            src={languageTag.flag}
            width={20}
            height={10}
            className=""
          />
        </button>
      </Popover.Trigger>
      <Popover.Content className="mr-14 z-50">
        <div className="flex content-baseline pl-2 pt-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="w-5 h-5"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"
            />
          </svg>
          <p className="Text mb-1 m-0 text-mauve12 text-base leading-5 font-medium pl-1">
            Language
          </p>
        </div>
        <select
          className="text-lg p-2"
          value={language}
          onChange={(e) => handleLanguageChange(e.target.value)}
        >
          <option value="ro">Romanian</option>
          <option value="en">English</option>
        </select>
      </Popover.Content>
    </Popover.Root>
  );
};

export default LanguageSwitcher;
