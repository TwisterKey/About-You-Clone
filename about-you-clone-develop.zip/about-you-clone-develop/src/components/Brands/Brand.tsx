import clsx from "clsx";
import React, { useState } from "react";
import Image from "next/image";

type BrandProps = {
  src: string;
  title: string;
  height: number;
  width: number;
} & JSX.IntrinsicElements["div"];

export const Brand = React.forwardRef<HTMLDivElement, BrandProps>(
  ({ className, ...props }, ref) => {
    const [isShown, setIsShown] = useState(false);

    return (
      <div
        className={clsx(
          "flex justify-center items-center mb-2 bg-gray-300 text-black h-12 w-24 relative ",
          className
        )}
        {...props}
        ref={ref}
        onMouseEnter={() => setIsShown(true)}
        onMouseLeave={() => setIsShown(false)}
      >
        <Image
          src={props.src}
          width={props.width}
          height={props.height}
          alt=""
        ></Image>
        {isShown && (
          <div className="bg-gray-300 text-gray-500 h-50 absolute inset-0 flex justify-center items-center">
            <h3>{props.title}</h3>
          </div>
        )}
      </div>
    );
  }
);

Brand.displayName = "Brands";
