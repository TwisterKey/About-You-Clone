import type { Meta, StoryObj } from "@storybook/react";
import { Button } from ".";
import { HeartIcon } from "@heroicons/react/24/outline";

const meta: Meta<typeof Button> = {
  title: "Elements/Button",
  component: Button,
  tags: ["autodocs"],
  argTypes: {},
  parameters: {
    backgrounds: { default: "light" },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;
export const ContainBlackClickEffect: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "black",
    children: "Incepem acum",
    enableClickEfect: true,
  },
};

export const ContainGreyHoverBackgroundEffect: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "grey",
    children: "Incepem acum",
    enableHoverEffect: "backgroundEffect",
  },
};

export const ContainGreenHoverTranslateUpEffect: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "green",
    children: "Incepem acum",
    enableHoverEffect: "translateEffectUp",
  },
};

export const ContainGreenHoverTranslateLeftRightEffect: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "green",
    children: "Incepem acum",
    enableHoverEffect: "translateEffectLeftRight",
  },
};

export const TextGreyHoverTextEffect: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "grey",
    children: "Incepem acum",
    enableHoverEffect: "textEffect",
  },
};

export const FullWidthContainedGreen: Story = {
  args: {
    variant: "contained",
    size: "veryLarge",
    color: "green",
    children: "Incepe acum",
    enableFullWidth: true,
    startIcon: <HeartIcon className="h-6 w-6 mx-2" />,
  },
};

export const IconContainedGreen: Story = {
  args: {
    variant: "contained",
    size: "veryLarge",
    color: "green",
    children: "Incepe acum",
    startIcon: <HeartIcon className="h-6 w-6 mx-2" />,
  },
};

export const ConteinedGreen: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "green",
    children: "Incepem acum",
  },
};
export const ConteinedBlack: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "black",
    children: "Incepem acum",
  },
};
export const ConteinedGrey: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "grey",
    children: "Incepem acum",
  },
};
export const ConteinedWhite: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "white",
    children: "Incepem acum",
  },
};
export const ConteinedRed: Story = {
  args: {
    variant: "contained",
    size: "large",
    color: "red",
    children: "Incepem acum",
  },
};

export const OutlineGreen: Story = {
  args: {
    variant: "outline",
    size: "large",
    color: "green",
    children: "Incepem acum",
  },
};
export const OutlineBlack: Story = {
  args: {
    variant: "outline",
    size: "large",
    color: "black",
    children: "Incepem acum",
  },
};
export const OutlineGrey: Story = {
  args: {
    variant: "outline",
    size: "large",
    color: "grey",
    children: "Incepem acum",
  },
};
export const OutlineWhite: Story = {
  args: {
    variant: "outline",
    size: "large",
    color: "white",
    children: "Incepem acum",
  },
};
export const OutlineRed: Story = {
  args: {
    variant: "outline",
    size: "large",
    color: "red",
    children: "Incepem acum",
  },
};

export const TextGreen: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "green",
    children: "Incepem acum",
  },
};
export const TextBlack: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "black",
    children: "Incepem acum",
  },
};
export const TextGrey: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "grey",
    children: "Incepem acum",
  },
};
export const TextWhite: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "white",
    children: "Incepem acum",
  },
};
export const TextRed: Story = {
  args: {
    variant: "text",
    size: "large",
    color: "red",
    children: "Incepem acum",
  },
};


