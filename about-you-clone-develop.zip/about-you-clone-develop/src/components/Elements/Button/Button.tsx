import clsx from "clsx";
import { ReactNode, useRef, useState } from "react";
import { twMerge } from "tailwind-merge";

type ButtonProps = JSX.IntrinsicElements["button"] & {
  size: "small" | "medium" | "large" | "veryLarge";
  variant: "text" | "outline" | "contained";
  color: "green" | "black" | "grey" | "white" | "red";
  startIcon?: ReactNode;
  endIcon?: ReactNode;
  enableFullWidth?: boolean;
  enableHoverEffect?:
    | "backgroundEffect"
    | "translateEffectUp"
    | "translateEffectLeftRight"
    | "textEffect";
  enableClickEfect?: boolean;
};

const variantStyles = {
  text: "border-none bg-none bg-transparent ",
  outline: "bg-transparent font-semibold border-2 border-grey",
  contained: "text-black-darker border-none font-semibold",
};

const sizeStyles = {
  small: "px-xxs py-xxs text-xs",
  medium: "px-xs py-xs text-xs",
  large: "px-2xl  py-sm text-sm",
  veryLarge: "px-2xl py-xs lg:px-4xl lg:py-sm text-xls",
};

const colorStyles = {
  green: "bg-green text-green",
  black: "bg-black-darker text-black-darker",
  grey: "bg-grey-light text-grey-dark",
  white: "bg-white text-white",
  red: "bg-red text-red",
};

const enableHoverEffectStyle = {
  backgroundEffect: "hover:bg-grey-lightDark",
  translateEffectUp:
    "hover:-translate-y-1 transition duration-300 ease-in-out hover:shadow-lg",
  translateEffectLeftRight: "animate-wiggle ",
  textEffect: "hover:text-black-dark transition duration-700 ease-in-out",
};

const sizeEffectStyle = {
  small: "w-xl h-xl",
  medium: "w-2xl h-2xl",
  large: "w-3xl h-3xl",
  veryLarge: "w-4xl h-4xl",
};

export const Button = ({
  variant,
  size,
  color,
  children,
  endIcon,
  startIcon,
  className,
  enableFullWidth,
  enableHoverEffect,
  enableClickEfect,
  ...props
}: ButtonProps) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [animationStyle, setAnimationStyle] = useState({});
  const [buttonActive, setButtonActive] = useState(false);

  const handleOnClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };

  const handleMouseDown = (event: React.MouseEvent<HTMLButtonElement>) => {
    const button = buttonRef.current;
    if (button && enableClickEfect) {
      const { left, top } = button.getBoundingClientRect();
      const x = event.clientX - left - 15;
      const y = event.clientY - top - 15;
      setAnimationStyle({ left: `${x}px`, top: `${y}px` });
      setButtonActive(false);
      setButtonActive(true);
      setTimeout(() => {
        setButtonActive(false);
      }, 320);
    }
  };

  return (
    <button
      ref={buttonRef}
      onClick={handleOnClick}
      onMouseDown={handleMouseDown}
      className={twMerge(
        clsx(
          "rounded-sm flex justify-center relative overflow-hidden",
          sizeStyles[size],
          colorStyles[color],
          variantStyles[variant],
          enableHoverEffect && enableHoverEffectStyle[enableHoverEffect],
          variant === "contained" && color === "black" && "text-white",
          variant === "contained" && color === "white" && "text-black-dark",
          enableFullWidth === true && "w-full",
          className
        )
      )}
      {...props}
    >
      <div
        className={clsx(
          enableClickEfect && buttonActive && "animate-ripple opacity-75",
          "absolute  opacity-0 bg-white  rounded-full ",
          sizeEffectStyle[size]
        )}
        style={animationStyle}
      />
      {startIcon}
      {children}
      {endIcon}
    </button>
  );
};
