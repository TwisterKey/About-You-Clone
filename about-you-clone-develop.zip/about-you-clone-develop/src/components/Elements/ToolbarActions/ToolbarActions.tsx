import {
  HeartIcon,
  ShoppingCartIcon,
  UserIcon,
} from "@heroicons/react/24/outline";
import { useTranslation } from "next-i18next";
import Link from "next/link";
import { useRouter } from "next/router";
import RootModal from "../LoginAndRegister/RootModal";
import { Badge } from "../Badge/Badge";
import { useCart } from "@/modules/cart/context/CartContext";

const ToolbarActions = () => {
  const { t: translate } = useTranslation("header");
  const router = useRouter();
  const { items } = useCart();

  return (
    <div className="inline-flex justify-center items-center font-medium mx-8">
      <div>
        <RootModal>
          <button className="inline-flex text-sm">
            <UserIcon className="w-5 mt-2 mr-2" />
            {translate("login")}
          </button>
        </RootModal>
      </div>
      <div>
        <Link
          className="bg-white mx-2 text-black border-1 border-solid border-gray-600 cursor-pointer"
          href={"/wishList"}
          locale={router.locale}
        >
          <button className="inline-flex text-sm">
            <HeartIcon className="w-5 mt-2 mr-2" />
            {translate("fav")}
          </button>
        </Link>
      </div>
      <div>
        <Link
          className="bg-white text-black mx-2 border-1 border-solid border-gray-600 cursor-pointer"
          href={"/cart"}
          locale={router.locale}
        >
          <button className="inline-flex text-sm">
            <ShoppingCartIcon className="w-5 mt-2 mr-2" />
            {translate("cart")}
            {items.length > 0 && (
              <span className="inline-flex items-center justify-center rounded-full mt-1 ml-2 w-6 h-6 bg-black text-xs text-white">
                {items.length}
              </span>
            )}
          </button>
        </Link>
      </div>
    </div>
  );
};

export default ToolbarActions;
