import clsx from "clsx";
import React from "react";

type TileProps = {
  shadow?: "sm" | "md" | "lg" | "xl" | "2xl";
} & JSX.IntrinsicElements["div"];

const shadows = {
  sm: "shadow-sm",
  md: "shadow-md",
  lg: "shadow-lg",
  xl: "shadow-xl",
  "2xl": "shadow-2xl",
};

export const Tile = React.forwardRef<HTMLDivElement, TileProps>(
  ({ className, shadow = "md", ...props }, ref) => {
    return (
      <div
        className={clsx(
          "px-5 py-7 mb-10 rounded-md border-2 border-gray-200 bg-white text-black",
          shadows[shadow],
          className
        )}
        {...props}
        ref={ref}
      />
    );
  }
);
Tile.displayName = "Tile";
