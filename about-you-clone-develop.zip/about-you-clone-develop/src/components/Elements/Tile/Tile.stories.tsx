import type { Meta, StoryObj } from '@storybook/react';

import { Tile } from './Tile';
import Image from 'next/image';

// More on how to set up stories at: https://storybook.js.org/docs/7.0/react/writing-stories/introduction
const meta: Meta<typeof Tile> = {
  title: 'Elements/Tile',
  component: Tile,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Tile>;

// More on writing stories with args: https://storybook.js.org/docs/7.0/react/writing-stories/args
export const Primary: Story = {
  args: {
    shadow: 'lg',
    children: 'Tile',
    className: 'font-bold',
  },   
  
};

export const TileExample: Story = {
  args: {
    shadow: 'lg',
    children: 'Tile',
    className: 'bg-white',
  },
  render: () => 
    <div>
      <p>Livrare</p>
      <div className="columns columns-2 w-72">
        <div>
        <Image
            src="https://cdn.aboutstatic.com/file/images/fa19849ab2114a6e97175be591fb4151.png?bg=F4F4F5&quality=75&trim=1&height=534&width=400"
            alt=""
            width={100}
            height={200}
          />
          </div>
          <div>
            <p>Urban Classics</p>
            <p>Fusta</p>
            <p>34</p>
            <a>mai multe culori</a>
          </div>
      </div>
    </div> 
};
