import React, { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { useForm } from "react-hook-form";
import { Button } from "../Button";
import Input from "./Input";
import * as RadioGroup from "@radix-ui/react-radio-group";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import RadioButton from "./RadioButton";

const schema = z.object({
  email: z
    .string({ required_error: "Email gresit " })
    .email({ message: "Te rugăm să-ți introduci adresa de e-mail" }),
  password: z
    .string({ required_error: "Parola trebuie sa aiba minim 6 caractere" })
    .min(6, { message: "Te rugăm să-ți introduci parola" }),
  firstname: z
    .string()
    .min(1, { message: "Te rugăm să-ți introduci prenumele" }),
  lastname: z.string().min(1, { message: "Te rugăm să-ți introduci numele" }),
  gender: z.string({ required_error: "Acest" }),
  news: z.string().optional(),
});

const RegisterTab = () => {
  const [isChecked, setIsChecked] = useState(false);

  const {
    getValues,
    setValue,
    watch,
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
  });

  useEffect(() => {
    setValue("news", "0");
    setValue("gender", "female");
  }, []);

  const handleCheckboxChange = (event: any) => {
    setIsChecked(event.target.checked);

    if (event.target.checked) {
      setValue("news", "1");
    } else {
      setValue("news", "0");
    }
  };

  const handleRadioButtonChange = (gender: string) => {
    setValue("gender", gender);
  };

  const onSubmit = (data: any) => {
    let adata = JSON.stringify(data);

    alert(adata);
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <fieldset className="flex justify-center mt-6">
          <Input
            name="firstname"
            id="name"
            register={register}
            errors={errors}
            placeholder="Prenume"
            type="text"
          />
          <Input
            name="lastname"
            id="name"
            register={register}
            errors={errors}
            placeholder="Nume"
            type="text"
          />
        </fieldset>
        <fieldset className="flex justify-center mt-6">
          <Input
            name="email"
            id="email"
            register={register}
            errors={errors}
            placeholder="Adresa ta de e-mail"
            type="text"
          />
          <Input
            name="password"
            id="password"
            register={register}
            errors={errors}
            placeholder="Parola (min 6 caractere)"
            type="password"
          />
        </fieldset>
        <div className="flex justify-between mt-7">
          <div className="ml-10">Formula de adresare</div>
          <form className="mr-10">
            <RadioGroup.Root
              className="flex gap-3"
              defaultValue="female"
              aria-label="View density"
            >
              <RadioButton
                testId="female"
                value="female"
                id="female"
                buttonName="Dna."
                register={register}
                onClick={() => handleRadioButtonChange("female")}
                errors={errors}
              />
              <RadioButton
                testId="male"
                value="male"
                id="male"
                buttonName="Dl."
                register={register}
                onClick={() => handleRadioButtonChange("male")}
                errors={errors}
              />
              <RadioButton
                testId="other"
                value="other"
                id="other"
                buttonName="Alt gen"
                register={register}
                onClick={() => handleRadioButtonChange("other")}
                errors={errors}
              />
            </RadioGroup.Root>
          </form>
        </div>
        <div className="flex items-center mt-3">
          <input
            id="link-checkbox"
            type="checkbox"
            value=""
            className="form-checkbox h-4 w-4 ml-10 mr-1"
            onChange={handleCheckboxChange}
          />
          <label
            htmlFor="link-checkbox"
            className={
              isChecked
                ? "ml-2 font-medium text-white dark:text-black text-xs"
                : "ml-2 font-medium text-white dark:text-gray-400 text-xs"
            }
          >
            Vreau să mă anunțați în viitor despre tendințe actuale, reduceri &
            coduri voucher <br></br>ABOUT YOU pe e-mail. Este oricând posibil să
            te dezabonezi.
          </label>
        </div>
        <div className="flex justify-center mt-4">
          {/* <Dialog.Close asChild> */}
          <Button
            size="medium"
            variant="text"
            color="white"
            className=" bg-black border border-solid border-black pr-10 pl-10 text-[15px] font-bold"
            type="submit"
          >
            Inregistreaza-te acum
          </Button>
          {/* </Dialog.Close> */}
        </div>
        <div className="text-[10px] text-center mt-5">
          Conform practicii obișnuite în orice magazin online, vei primi toate
          actualizările relevante pe e-mail<br></br> (confirmarea
          comenzii,confirmarea livrării, informații cu privire la retur,
          recomandări). Poți să te dezabonezi<br></br>oricând de la recomandări.
        </div>
        <div className="text-[10px] text-center mt-1 underline pb-4">
          <a href="#">Politica de confidentialitate</a>
        </div>
      </form>
    </>
  );
};

export default RegisterTab;
