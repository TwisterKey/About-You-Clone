import React, { ChangeEvent, useState, useReducer } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import * as Tabs from "@radix-ui/react-tabs";
import { Button } from "../Button";
import Input from "./Input";
import { useForm } from "react-hook-form";
import { z, ZodType } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const schema = z.object({
  email: z
    .string({ required_error: "Email is required" })
    .email({ message: "Email gresit" }),
  password: z
    .string({ required_error: "Password is required" })
    .min(6, { message: "Parola trebuie sa aibe 6 caractere" }),
});

const LoginTab = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
  });

  const onSubmit = (d: any) => alert(JSON.stringify(d));

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <fieldset className="flex justify-center mt-6">
          <Input
            name="email"
            id="email"
            register={register}
            errors={errors}
            placeholder="Adresa ta de e-mail"
            type="text"
          />
          <Input
            name="password"
            id="password"
            register={register}
            errors={errors}
            placeholder="Parola"
            type="password"
          />
        </fieldset>
        <div className="flex justify-end mt-4 text-gray-400 mr-[50px]">
          <button>Ai uitat parola?</button>
        </div>

        <div className="flex justify-center mt-5 pb-7">
          {/* <Dialog.Close asChild> */}
          <Button
            size="medium"
            variant="text"
            color="white"
            className=" bg-black border border-solid border-black pr-24 pl-24 text-[15px] font-bold"
            type="submit"
          >
            Logare
          </Button>
        </div>
      </form>
    </>
  );
};

export default LoginTab;
