import React, { ChangeEvent, ReactNode, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Cross2Icon } from "@radix-ui/react-icons";
import * as Tabs from "@radix-ui/react-tabs";
import clsx from "clsx";
import { Button } from "../Button";
import LoginTab from "./LoginTab";
import RegisterTab from "./RegisterTab";

type RootModalProps = {
  children: ReactNode;
};

const RootModal = ({ children }: RootModalProps) => {
  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>{children}</Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="bg-gray-300 fixed inset-0 z-40" />
        <Dialog.Content className="bg-white w-[620px] h-auto z-50 rounded-6 fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 focus:outline-none text-black">
          <Dialog.Title className="flex items-center justify-between">
            <div className="text-black text-xl flex-1 p-5 font-bold text-center">
              Logare
            </div>
            <Dialog.Close asChild className="flex items-center pr-2">
              <button
                className="text-black font-bold flex content-end text-xl"
                aria-label="Close"
              >
                <Cross2Icon className="h-5 w-5" />
              </button>
            </Dialog.Close>
          </Dialog.Title>
          <hr className="border border-solid border-gray-200 flex-grow" />
          <Tabs.Root className="" defaultValue="login">
            <Tabs.List
              className="flex justify-center items-center mt-10 pr-7"
              aria-label="Manage your account"
            >
              <Tabs.Trigger
                className="data-[state=active]:text-black data-[state=active]:border-black text-gray-300 font-bold border-solid border-gray-300 border-[1px] pl-7 pr-7 text-[12px] pt-[6px] pb-[6px] rounded-sm "
                value="register"
              >
                Inregistreaza-te
              </Tabs.Trigger>
              <Tabs.Trigger
                value="login"
                className="data-[state=active]:text-black data-[state=active]:border-black text-gray-300 font-bold border-solid border-gray-300 border-[1px] pl-14 pr-14 text-[12px] pt-[6px] pb-[6px] rounded-sm "
              >
                Logare
              </Tabs.Trigger>
            </Tabs.List>
            <Dialog.Description className=" text-xs mt-9 flex justify-center text-gray-300">
              <hr className="border border-solid border-gray-200 flex-grow mr-2 mt-[7px]" />
              Logheaza-te cu adresa de email
              <hr className="border border-solid border-gray-200 flex-grow ml-2 mt-[7px]" />
            </Dialog.Description>
            <Tabs.Content value="login">
              <LoginTab />
            </Tabs.Content>
            <Tabs.Content value="register">
              <RegisterTab />
            </Tabs.Content>
          </Tabs.Root>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default RootModal;
