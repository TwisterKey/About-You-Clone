import React, { ChangeEvent, useState, InputHTMLAttributes } from "react";
import clsx from "clsx";
import * as RadioGroup from "@radix-ui/react-radio-group";
import { useForm, UseFormRegister, FieldValues } from "react-hook-form";

interface RBProps extends InputHTMLAttributes<HTMLInputElement> {
  register: UseFormRegister<FieldValues>;
  buttonName: string;
  value: string;
  errors?: any;
  testId: string; // adăugați proprietatea testId
}

const RadioButton: React.FC<RBProps> = ({
  value,
  id,
  buttonName,
  register,
  errors,
  testId,
  onClick,
}) => {
  return (
    <div className=" inline-flex items-center" onClick={onClick}>
      <RadioGroup.Item
        className="bg-white border border-solid border-black w-[20px] h-[20px] rounded-full relative mr-1"
        value={value}
        id={id}
        data-testid={testId} // folosiți data-testid în loc de name
        {...register(testId)} // înregistrați valoarea folosind testId în loc de name
      >
        <RadioGroup.Indicator className="flex items-center justify-center absolute inset-0">
          <div className="w-[8px] h-[8px] rounded-full bg-black inline-block "></div>
        </RadioGroup.Indicator>
      </RadioGroup.Item>
      <label className=" inline-block font-bold text-[14px]" htmlFor={id}>
        {buttonName}
      </label>
      {errors && errors[testId] && errors[testId]?.message && (
        <p className="text-red-500 text-[10px] mt-2 ml-4">
          {errors[testId]?.message as string}{" "}
        </p>
      )}
    </div>
  );
};

export default RadioButton;
