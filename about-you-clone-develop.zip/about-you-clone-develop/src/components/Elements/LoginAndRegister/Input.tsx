// @ts-nocheck
import React, { ChangeEvent, InputHTMLAttributes, useState } from "react";
import clsx from "clsx";
import { useForm, UseFormRegister, FieldValues } from "react-hook-form";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  register: UseFormRegister<FieldValues>;
  errors?: any;
}

const Input: React.FC<InputProps> = ({
  placeholder,
  type,
  name = "",
  register,
  errors,
  ...props
}) => {
  const [inputValue, setInputValue] = useState("");

  function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
    setInputValue(event.target.value);
  }

  return (
    <label className=" relative">
      <input
        animation={inputValue ? "animation2" : "animation1"}
        type={type}
        className={clsx(
          "border bg-gray-200 p-2 mr-5 text-black w-[250px] outline-none hover:border hover:border-black hover:border-s focus:border focus:border-black focus:border-s focus:bg-white",
          inputValue && "bg-white border border-black border-s",
          errors && errors[name] && "border-red-600"
        )}
        {...register(name)}
        {...props}
        onChange={handleInputChange}
      />

      {errors && errors[name] && errors[name]?.message && (
        <p className="text-red-500 text-[10px] mt-2 ml-4">
          {errors[name]?.message as string}{" "}
        </p>
      )}

      {errors && errors[name] && (
        <div className="absolute right-[25px] top-[20px] transform -translate-y-1/2">
          <svg width="24" height="24" viewBox="0 0 24 24">
            <path
              fill="red"
              d="M12 4c-4.416 0-8 3.584-8 8s3.584 8 8 8 8-3.584 8-8-3.584-8-8-8zm.8 12h-1.6v-1.6h1.6V16zm0-3.2h-1.6V8h1.6v4.8z"
            />
          </svg>
        </div>
      )}
      <span className=" text-gray-500 ml-2 mr-2 absolute left-0 top-2 mx-1 px-[2px] transition duration-200 input-text cursor-text  pointer-events-none">
        {placeholder}
      </span>
    </label>
  );
};

export default Input;
