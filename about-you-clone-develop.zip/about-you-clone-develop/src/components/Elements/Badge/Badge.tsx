import clsx from "clsx";
import React from "react";
import { HeartIcon } from "@heroicons/react/24/outline";

type BadgeProps = {
  text: string;
  number: number;
} & JSX.IntrinsicElements["span"];

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ text, number, className, ...props }, ref) => {
    const isLargeNumber = number > 999;
    return (
      <span
        className={clsx("inline-block font-bold text-white ", className)}
        {...props}
        ref={ref}
      >
        <span className="inline-flex items-center">
          <HeartIcon className="h-6 w-6 mr-3" />
          <span className="mt-1">
            {text}
            <span
              className={clsx(
                "inline-flex items-center justify-center rounded-full ml-2",
                {
                  "w-7 h-7 bg-black text-xs": !isLargeNumber,
                  // "bg-red h-4 w-auto px-2 font-semibold text-xs box-border tracking-wide":
                  //   isLargeNumber,
                  "w-8 h-8 bg-black text-[10px]": isLargeNumber,
                }
              )}
            >
              {number}
            </span>
          </span>
        </span>
      </span>
    );
  }
);
Badge.displayName = "Badge";
