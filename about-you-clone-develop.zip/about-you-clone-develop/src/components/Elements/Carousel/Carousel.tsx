import React, { useEffect, useState } from "react";
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/solid";
import Image from "next/image";

//Props for the Carousel component
export type CarouselProps = {
  //An array of objects representing each slide
  items: {
    //The source URL of the image
    src: string;
    //The alternate text for the image
    alt: string;
    // The hyperlink for the slide, if any
    href?: string;
  }[];
  // The delay in milliseconds between each slide transition
  delay?: number;
};

// The Carousel component accepts an array of items and an optional delay prop
const Carousel = ({ items, delay = 3000 }: CarouselProps) => {
  // currentSlide keeps track of the current slide index, and setCurrentSlide is used to update it
  const [currentSlide, setCurrentSlide] = useState(0);

  // prevSlide and nextSlide are event handlers that update the currentSlide state
  const prevSlide = () => {
    // If the current slide is the first slide, go to the last slide, otherwise go to the previous slide
    setCurrentSlide((currentSlide - 1 + items.length) % items.length);
  };

  const nextSlide = () => {
    // If the current slide is the last slide, go to the first slide, otherwise go to the next slide
    setCurrentSlide((currentSlide + 1) % items.length);
  };

  // The useEffect hook is used to set up a timer that automatically advances the slide every delay milliseconds
  useEffect(() => {
    // Set up a new timer using `setInterval`
    const timer = setInterval(() => {
      setCurrentSlide((currentSlide + 1) % items.length);
    }, delay);

    // The return function inside `useEffect` is used to clean up the timer when the component unmounts or the delay or items.length props change
    return () => clearInterval(timer);
  }, [currentSlide, delay, items.length]);

  // The Dots component renders a series of dots at the bottom of the carousel that represent each slide
  const Dots = () => (
    <div className="absolute bottom-0 left-0 right-0 z-10 flex justify-center items-center w-full h-14">
      {items.map((item, index) => (
        <button
          key={index}
          onClick={() => setCurrentSlide(index)}
          className={`h-5 w-5 mx-1 rounded-full transition duration-300 ease-in-out ${
            index === currentSlide
              ? "bg-white"
              : "bg-gray-400 opacity-50 hover:opacity-75 active:opacity-100 hover:bg-white"
          }`}
        />
      ))}
    </div>
  );
  // The Carousel component renders the carousel UI using the Image component from Next.js and the ChevronLeftIcon and ChevronRightIcon components from Hero icons
  return (
    <div className="relative w-full left-0 right-0">
      <div className="overflow-hidden h-96 md:h-[600px]">
        <div
          className="flex transition-all duration-300 ease-in-out h-full"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {items.map((item, index) => (
            <div key={index} className="w-full flex-shrink-0">
              <a href={item.href}>
                <Image
                  src={item.src}
                  alt={item.alt}
                  width={1920}
                  height={1080}
                  className="object-cover w-full h-full"
                />
              </a>
            </div>
          ))}
        </div>
      </div>
      <button
        onClick={prevSlide}
        className="h-100 w-30 absolute top-1/2 left-0 z-10 bg-white bg-opacity-80 hover:scale-105 hover:w-11 hover:translate-x-0 transition-all duration-150 ease-in-out transform -translate-y-1/2 flex justify-end items-center"
      >
        <ChevronLeftIcon className="h-5 w-5 text-black absolute left-0 right-0 m-auto" />
      </button>
      <button
        onClick={nextSlide}
        className="h-100 w-30 absolute top-1/2 right-0 z-10 bg-white bg-opacity-80 hover:scale-105 hover:w-11 hover:translate-x-0 transition-all duration-150 ease-in-out transform -translate-y-1/2 flex justify-end items-center flex-row-reverse"
      >
        <ChevronRightIcon className="h-5 w-5 text-black absolute left-0 right-0 m-auto" />
      </button>
      <Dots />
    </div>
  );
};
export default Carousel;
