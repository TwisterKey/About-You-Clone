import React from "react";
import "tailwindcss/base.css";
import "tailwindcss/components.css";
import "tailwindcss/utilities.css";
import "tailwindcss-animations";
import clsx from "clsx";
import Link from "next/link";

interface LogoProps {
  headerText: string;
}

const Logo: React.FC<LogoProps> = ({ headerText }) => {
  return (
    <Link href="/">
      <div
        className={clsx(
          // Add cursor pointer style to the div
          "flex items-center cursor-pointer select-none",
          // Add class for uncopiable text
          "not-selectable"
        )}
        // Call the click handler on click event
      >
        <div
          className={clsx(
            "font-sans font-bold pr-1 p-1/2 pl-1 mr-0.5 bg-black text-white"
          )}
        >
          ABOUT
        </div>
        <div
          className={clsx(
            "font-sans font-bold bg-black text-white p-1/2 pr-1 pl-1 flex items-center",
            headerText && "animate-fade-in-right"
          )}
        >
          {headerText ? headerText.toUpperCase() : "YOU"}
          <svg className="w-4 h-4 fill-current text-white" viewBox="0 1 8 8">
            <circle
              cx="4"
              cy="4"
              r="3"
              stroke="white"
              strokeWidth="1"
              fill="black"
            />
          </svg>
        </div>
      </div>
    </Link>
  );
};

export default Logo;
