import * as RadixPopover from '@radix-ui/react-popover';

export const PopoverArrow = RadixPopover.Arrow;
