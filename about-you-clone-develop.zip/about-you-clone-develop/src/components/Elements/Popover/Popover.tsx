import * as RadixPopover from '@radix-ui/react-popover';

export const Popover = RadixPopover.Root;
