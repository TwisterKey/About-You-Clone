import clsx from 'clsx';

type TopHeaderProps = JSX.IntrinsicElements['div'];
  
export const TopHeader = ({ children, className, ...props }: TopHeaderProps) => {
return (
    <div
    className={clsx(
        'h-8 w-full bg-slate-100 text-black',
        className
    )}
    {...props}
    >
    {children}
    </div>
);
};