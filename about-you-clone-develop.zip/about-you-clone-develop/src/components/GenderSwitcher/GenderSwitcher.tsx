import useLocalStorage from "@/hooks/useLocalStorage";
import { useTranslation } from "next-i18next";
import * as ToggleGroup from "@radix-ui/react-toggle-group";
import { useRouter } from "next/router";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useGender } from "@/context/GenderContext";

const toggleGroupItemClasses =
  "text-slate-400 h-11 font-medium hover:text-black-dark data-[state=on]:text-black-dark items-center justify-center bg-white text-base px-4 data-[state=on]:border-b-2 border-black-dark focus:ring-blue-500 transition-all duration-300";

const GenderSwitcher = () => {
  const router = useRouter();
  const { t: translate } = useTranslation("header");
  const { gender, setGender } = useGender();

  const handleGenderChange = (newGender: string) => {
    // localStorage.setItem("gender", newGender);
    setGender(newGender);
    // router.push(`/products/${newGender}` as any, undefined, { shallow: true });
  };

  return (
    <ToggleGroup.Root
      className="flex justify-between mx-8"
      type="single"
      value={gender}
      onValueChange={(newValue: string) => handleGenderChange(newValue)}
    >
      <ToggleGroup.Item className={toggleGroupItemClasses} value="women">
        {translate("women")}
      </ToggleGroup.Item>
      <ToggleGroup.Item className={toggleGroupItemClasses} value="men">
        {translate("men")}
      </ToggleGroup.Item>
      <ToggleGroup.Item className={toggleGroupItemClasses} value="children">
        {translate("children")}
      </ToggleGroup.Item>
    </ToggleGroup.Root>
  );
};

export default GenderSwitcher;
