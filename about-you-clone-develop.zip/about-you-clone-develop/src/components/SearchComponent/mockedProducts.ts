export const mockedProducts = [
    {
        id: 1,
        name: 'Tricou',
        brand: 'Nike',
        category: 'Tipuri de sport'
    },
    {
        id: 2,
        name: 'Fusta',
        brand: 'Nike Sportwear',
        category: 'Imbracaminte sport'
    },
    {
        id: 3,
        name: 'Pantaloni',
        brand: 'Nike Swim',
        category: 'Sport'
    },
    {
        id: 4,
        name: 'Pantaloni',
        brand: 'Adidas',
        category: 'Sport'
    },
]