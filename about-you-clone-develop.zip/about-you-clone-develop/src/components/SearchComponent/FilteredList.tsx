interface Product {
  id: any;
  name: string;
  brand: string;
  category: string;
}

interface ListProps {
  inputValue: string;
  items: Product[];
  labelKey: keyof Product;
  translationKey: string;
}

const FilteredList: React.FC<ListProps> = (props) => {
  const { inputValue, items, labelKey, translationKey } = props;

  return (
    <div>
      <h1 className="pl-2 text-sm text-grey-dark font-semibold">
        {translationKey}
      </h1>
      {items
        .filter(
          (item) =>
            inputValue === "" ||
            (item[labelKey] ?? "")
              .toLowerCase()
              .includes(inputValue.toLowerCase())
        )
        .map((item) => (
          <div key={item.id}>
            <p className="pl-2 text-sm text-black font-medium">
              {item[labelKey]}
            </p>
          </div>
        ))}
    </div>
  );
};

export default FilteredList;
