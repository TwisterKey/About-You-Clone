import { useTranslation } from "next-i18next";
import { useState } from "react";
import { mockedProducts } from "./mockedProducts";
import Results from "./Results";
import FilteredList from "./FilteredList";

const SearchComponent = () => {
  const { t: translate } = useTranslation("common");
  const Categories = (props: any) => {
    return (
      <FilteredList
        {...props}
        items={mockedProducts}
        labelKey="category"
        translationKey={translate("category")}
      />
    );
  };
  const Brands = (props: any) => {
    return (
      <FilteredList
        {...props}
        items={mockedProducts}
        labelKey="brand"
        translationKey={translate("brands")}
      />
    );
  };
  const Products = (props: any) => {
    return (
      <FilteredList
        {...props}
        items={mockedProducts}
        labelKey="name"
        translationKey={translate("products")}
      />
    );
  };

  const [inputValue, setInputValue] = useState("");
  const handleInputChange = (event: any) => {
    setInputValue(event.target.value);
  };

  return (
    <div className="flex items-center justify-end">
      <div className="relative text-gray-600 focus-within:text-gray-600 sm:w-full md:w-auto sm:mb-4 md:mb-0">
        <span className="absolute left-0 flex items-center pl-2 pt-3">
          <button
            type="submit"
            className="p-1 focus:outline-none focus:shadow-outline"
          >
            <svg
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              className="w-4 h-4"
            >
              <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
          </button>
        </span>
        <input
          value={inputValue}
          onChange={handleInputChange}
          type="text"
          placeholder={translate("search")}
          className="w-72 pt-0.5 h-9 pl-10 text-xs text-black border rounded-none outline-none bg-grey-lightLight focus:bg-grey-lightLight focus:border-grey-ligthLigth sm:w-full md:w-72"
        />
        {inputValue.length > 0 && (
          <div className="z-50 divide-y absolute w-full shadow bg-white">
            <Results inputValue={inputValue} />
            <Brands inputValue={inputValue} />
            <Categories inputValue={inputValue} />
            <Products inputValue={inputValue} />
          </div>
        )}
      </div>
    </div>
  );
};
export default SearchComponent;
