import { useTranslation } from "next-i18next";

const Results = (props: { inputValue: string }) => {
  const { t: translate } = useTranslation("common");
  return (
    <div className="pl-4 pt-4 flex justify-between flex-row text-xs">
      <div className="text-black">
        <svg
          fill="none"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          viewBox="0 0 24 24"
          className="w-6 h-6 text-grey-dark"
        >
          <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
        </svg>
      </div>
      <div>{props.inputValue}</div>
      <div>
        <button className="pr-4 text-sm text-grey-dark font-semibold">
          {translate("results")}
        </button>
      </div>
    </div>
  );
};

export default Results;
