import { createContext, useContext, useState } from "react";

interface GenderContextData {
  gender: string;
  setGender: (gender: string) => void;
}

type GenderProviderProps = {
  children: React.ReactNode;
};

const GenderContext = createContext<GenderContextData | undefined>(undefined);

export const useGender = () => {
  const context = useContext(GenderContext);
  if (!context) {
    throw new Error("useGender must be used within a GenderProvider");
  }
  return context;
};

export const GenderProvider = ({ children }: GenderProviderProps) => {
  const [gender, setGender] = useState<string>("men");

  return (
    <GenderContext.Provider
      value={{
        setGender,
        gender,
      }}
    >
      {children}
    </GenderContext.Provider>
  );
};
