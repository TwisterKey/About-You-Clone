import { useEffect, useState } from 'react';
import { Breakpoint, Breakpoints } from '@/types/layout';

export const useScreenSize = () => {
  // Initialize state for width with the current window inner width
  const [width, setWidth] = useState<number>(0);
  // Initialize state for height with the current window inner height
  const [height, setHeight] = useState<number>(0);

  // This function checks if current screen size is above a certain breakpoint
  const isAbove = (breakpoint: Breakpoint) => {
    // Return true if current width is greater than the breakpoint width
    return width > breakpoint;
  };

  // Set initial screen size state on component mount
  useEffect(() => {
    setWidth(window.innerWidth);
    setHeight(window.innerHeight);
  }, []);

  // Add a resize event listener to the window
  useEffect(() => {
    // This function handles resize events
    const handleResize = () => {
      // Update the width state with the current window inner width
      setWidth(window.innerWidth);
      // Update the height state with the current window inner height
      setHeight(window.innerHeight);
    };
    // Add the event listener
    window.addEventListener('resize', handleResize);

    // Remove the event listener when the component unmounts
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [width, height]);

  // Return the current width, height, and isAbove function
  return {
    width,
    height,
    isAbove,
  };
};
