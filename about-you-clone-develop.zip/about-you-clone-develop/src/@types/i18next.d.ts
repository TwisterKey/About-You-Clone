import "i18next"; // before v13.0.0 -> import 'react-i18next';
import type common from "../../public/locales/en/common.json";
import type footer from "../../public/locales/en/footer.json";
import type header from "../../public/locales/en/header.json";

interface I18nNamespaces {
  common: typeof common;
  footer: typeof footer;
  header: typeof header;
}
// before v13.0.0 -> declare module 'react-i18next'
declare module "i18next" {
  interface CustomTypeOptions {
    defaultNS: "common";
    resources: I18nNamespaces;
  }
}
