interface Config {
  apiUrl: string;
  siteName: string;
}

const appConfig: Config = {
  apiUrl: process.env.NEXT_API_URL as string,
  siteName: (process.env.NEXT_SITE_NAME as string) || "Next Boilerplate",
};

export default appConfig;
