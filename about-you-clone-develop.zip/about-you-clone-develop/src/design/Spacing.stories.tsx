import { Meta, StoryObj } from "@storybook/react";

type IspacingProps = {
  size: "xxs" | "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl";
};

export const Spacing = ({ size = "xxs" }: IspacingProps) => {
  interface IspacingValues {
    xxs: string;
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    "2xl": string;
    "3xl": string;
    "4xl": string;
  }
  const spacingValues: IspacingValues = {
    xxs: "5px",
    xs: "10px",
    sm: "16px",
    md: "20px",
    lg: "24px",
    xl: "30px",
    "2xl": "40px",
    "3xl": "60px",
    "4xl": "80px",
  };
  const style = [
    "h-[5px]",
    "h-[10px]",
    "h-[16px]",
    "h-[20px]",
    "h-[24px]",
    "h-[30px]",
    "h-[40px]",
    "h-[60px]",
    "h-[80px]",
    "mb-xxs",
    "mb-xs",
    "mb-sm",
    "mb-md",
    "mb-lg",
    "mb-xl",
    "mb-2xl",
    "mb-3xl",
    "mb-4xl",
  ];
  return (
    <div>
      <section className=" flex justify-around items-end">
        {(Object.keys(spacingValues) as (keyof typeof spacingValues)[]).map(
          (spacingSize) => {
            return (
              <section
                key={spacingSize}
                className="flex flex-col items-center w-20"
              >
                <div
                  className={`bg-red-400 w-20 h-[${spacingValues[spacingSize]}]`}
                ></div>
                <div className="text-black-dark pt-4">
                  <span className="text-xl">{spacingSize}</span>
                  &ensp;
                  <span className="text-sm">{spacingValues[spacingSize]}</span>
                </div>
              </section>
            );
          }
        )}
      </section>
      <section className="flex flex-col items-center mt-24">
        <div
          className={`border-red-400 border-2 rounded-lg flex justify-center w-3/6 py-5 text-black-dark text-lg mb-${size}`}
        >
          Content
        </div>
        <div className="border-red-400 border-2 rounded-lg flex justify-center w-3/6 py-5 text-black-dark text-lg">
          Content
        </div>
      </section>
    </div>
  );
};

const meta: Meta<typeof Spacing> = {
  title: "Spacing",
  component: Spacing,
  args: {
    size: "xxs",
  },
  parameters: {
    backgrounds: { default: "light" },
  },
};

export default meta;
type Story = StoryObj<typeof Spacing>;

const SpacingDiv: Story = {
  args: {
    size: "xxs",
  },
};
