/** @type {import('next').NextConfig} */

const withRoutes = require("nextjs-routes/config")();
const { i18n } = require("./next-i18next.config");
const nextConfig = {
  reactStrictMode: true,
  i18n,
};

module.exports = withRoutes(nextConfig);
